package com.novelcraft.writer;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.example.liquidglass.LiquidGlassButton;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.novelcraft.writer.glass.GlassWallpaperDrawable;

/**
 * 运行时配色管理：暗黑（默认）/ 明亮（3.8.3 配色）/ 自定义（自定背景色 + 文字色）。
 * 只改视觉，不动任何控件 id 与业务逻辑。
 *
 * 关键点：每个控件第一次被着色时，把它原来的“资源色”记在 tag 里；
 * 之后任何一次切换都基于这个原始色重新映射到目标调色板，
 * 因此可在三种主题间反复切换而不会出现颜色残留/混色。
 */
public class ThemeManager {

    public static final String PREFS = "editor_prefs";
    public static final String KEY_MODE = "theme_mode";
    public static final String KEY_BG = "theme_bg";
    public static final String KEY_TEXT = "theme_text";

    public static final String MODE_DARK = "dark";
    public static final String MODE_LIGHT = "light";
    public static final String MODE_CUSTOM = "custom";

    // 默认配色（暗黑）
    private static final int DEF_BG = 0xFF121212;
    private static final int DEF_TEXT = 0xFFF5F5F5;

    // 调色板下标
    private static final int P_BG = 0;          // 背景
    private static final int P_CARD = 1;        // 卡片
    private static final int P_CARD_SOFT = 2;   // 次级卡片/输入框
    private static final int P_TEXT = 3;        // 主文字
    private static final int P_TEXT_SEC = 4;    // 次文字
    private static final int P_HINT = 5;        // 提示
    private static final int P_ACCENT = 6;      // primary_color
    private static final int P_ACCENT_DARK = 7; // primary_dark
    private static final int P_SECONDARY = 8;   // secondary_color
    private static final int P_ACCENT2 = 9;     // accent_color
    private static final int P_ON_ACCENT = 10;  // button_text
    private static final int P_HEADER = 11;     // 顶栏
    private static final int P_ERROR = 12;      // error
    private static final int P_ON_PRIMARY = 13; // on_primary_text
    private static final int P_NOVEL = 14;      // novel_text

    public static String getMode(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MODE, MODE_DARK);
    }

    public static void setMode(Context c, String mode) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_MODE, mode).apply();
    }

    public static int getBg(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_BG, DEF_BG);
    }

    public static int getText(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_TEXT, DEF_TEXT);
    }

    public static void setCustom(Context c, int bg, int text) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putInt(KEY_BG, bg).putInt(KEY_TEXT, text).apply();
    }

    /** 运行期设置文字颜色的统一入口：明亮模式一律黑色，其余返回资源色。 */
    public static int textColor(Activity a, int resId) {
        if (MODE_LIGHT.equals(getMode(a))) return 0xFF000000;
        return a.getResources().getColor(resId);
    }

    /** 在 Activity 的 onResume/onCreate 调用，按当前配置给整棵视图树着色（幂等，可重复调用）。 */
    public static void apply(Activity a) {
        int[] p = palette(a);
        boolean light = MODE_LIGHT.equals(getMode(a));
        try {
            Window window = a.getWindow();
            // 液态玻璃底：窗口背景铺满壁纸，状态栏/导航栏透明，内容透过玻璃才能“被折射”
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            window.setBackgroundDrawable(new GlassWallpaperDrawable(a));
        } catch (Exception ignored) {
        }
        View decor = a.getWindow().getDecorView();
        int vis = 0;
        if (light) {
            vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vis |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        }
        decor.setSystemUiVisibility(vis);
        View content = a.findViewById(android.R.id.content);
        if (content instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) content;
            for (int i = 0; i < g.getChildCount(); i++) {
                applyView(g.getChildAt(i), p, a);
            }
        }
        setupLiquidGlass(a);
    }

    /** 液态玻璃组件设置：只有会拖动/滚动的内容才动态采样，其余静态采样（安卓 12 省性能）。 */
    private static void setupLiquidGlass(Activity a) {
        boolean light = MODE_LIGHT.equals(getMode(a));
        try {
            View nav = a.findViewById(R.id.bottomNavBar);
            if (nav instanceof com.example.liquidglass.LiquidGlassView) {
                com.example.liquidglass.LiquidGlassView g = (com.example.liquidglass.LiquidGlassView) nav;
                g.setEnableDynamicBackground(true);
                g.setCollectFrameStats(false);
                g.setEnableAdaptiveTint(false);
                g.setGlassTint(light ? 0x14000000 : 0x26FFFFFF);
                if (nav instanceof com.example.liquidglass.LiquidGlassTabBar) {
                    ((com.example.liquidglass.LiquidGlassTabBar) nav)
                            .setSelectedTintColor(light ? 0xFF000000 : 0xFFFFFFFF);
                }
            }
        } catch (Throwable ignored) {
        }
        int[] staticIds = {R.id.cardHero, R.id.cardNovel};
        for (int id : staticIds) {
            try {
                View v = a.findViewById(id);
                if (v instanceof com.example.liquidglass.LiquidGlassView) {
                    com.example.liquidglass.LiquidGlassView g = (com.example.liquidglass.LiquidGlassView) v;
                    g.setEnableDynamicBackground(false);
                    g.setCollectFrameStats(false);
                    g.setEnableAdaptiveTint(false);
                    g.setGlassTint(light ? 0x1A000000 : 0x1FFFFFFF);
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private static void applyView(View v, int[] p, Activity a) {
        // 库自带控件（LiquidGlassButton / TabBar / Chip）的标签由库管理；
        // 但背景是纯黑/纯白，这里直接给出确定性的文字色，兼容安卓 12（无自适应着色）
        if (v.getParent() instanceof com.example.liquidglass.LiquidGlassButton
                || v.getParent() instanceof com.example.liquidglass.LiquidGlassTabBar
                || v.getParent() instanceof com.example.liquidglass.LiquidGlassChip) {
            if (v instanceof TextView) {
                String mode = getMode(a);
                if (MODE_LIGHT.equals(mode)) {
                    ((TextView) v).setTextColor(0xFF000000);
                } else if (MODE_CUSTOM.equals(mode)) {
                    ((TextView) v).setTextColor(getText(a));
                } else {
                    ((TextView) v).setTextColor(0xFFF5F5F5);
                }
            }
            return;
        }
        // 所有液态玻璃控件：黑/白主题下关闭自适应着色，直接给确定性色调（安卓 12 友好、省电）
        if (v instanceof com.example.liquidglass.LiquidGlassView) {
            com.example.liquidglass.LiquidGlassView g = (com.example.liquidglass.LiquidGlassView) v;
            g.setEnableAdaptiveTint(false);
            g.setCollectFrameStats(false);
            g.setGlassTint(MODE_LIGHT.equals(getMode(a)) ? 0x12000000 : 0x1AFFFFFF);
        }
        // 1) 容器背景
        if (v instanceof ViewGroup
                && !(v instanceof LiquidGlassButton) && !(v instanceof CompoundButton) && !(v instanceof EditText)) {
            Drawable d = v.getBackground();
            if (d instanceof GradientDrawable) {
                if (isHeaderGradient(v, a)) {
                    d.mutate();
                    if (MODE_LIGHT.equals(getMode(a))) {
                        ((GradientDrawable) d).setColors(new int[]{p[P_HEADER], p[P_BG]});
                    } else {
                        // 液态玻璃：顶部只留一层极淡的暗色压暗，露出壁纸
                        ((GradientDrawable) d).setColors(new int[]{0x40000000, 0x14000000, 0x00000000});
                    }
                } else {
                    d.mutate();
                    ((GradientDrawable) d).setColor(p[P_CARD]);
                }
            } else if (d instanceof ColorDrawable) {
                Integer target = resolveBg(v, ((ColorDrawable) d).getColor(), a, p);
                if (target != null) v.setBackgroundColor(target);
            }
        }

        // 2) 文字
        if (v instanceof EditText) {
            EditText e = (EditText) v;
            e.setTextColor(p[P_TEXT]);
            e.setHintTextColor(p[P_HINT]);
            Drawable d = e.getBackground();
            if (d instanceof GradientDrawable) {
                d.mutate();
                ((GradientDrawable) d).setColor(p[P_CARD_SOFT]);
            }
        } else if (v instanceof TextView) {
            TextView t = (TextView) v;
            t.setTextColor(resolveText(t, a, p));
        }

        // 3) 按钮底色（backgroundTint）
        if (v instanceof LiquidGlassButton && !(v instanceof CompoundButton) && !(v instanceof EditText)) {
            ColorStateList csl = v.getBackgroundTintList();
            if (csl != null) {
                int target = resolveTint(v, csl.getDefaultColor(), a, p);
                if (target != 0) v.setBackgroundTintList(ColorStateList.valueOf(target));
            }
        }

        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                applyView(g.getChildAt(i), p, a);
            }
        }
    }

    // ---- 着色解析：优先识别“资源键色”，否则回退到已记忆的原始键色 ----
    // 这样既能覆盖 Java 运行期设置的资源色（如底部导航选中态），
    // 又能在多次切换主题后仍基于原始键色重新映射，杜绝颜色残留。

    private static int resolveText(TextView t, Activity a, int[] p) {
        int cur = t.getCurrentTextColor();
        // 明亮模式：所有文字统一黑色（先记录原始色，切回暗黑/自定义时能正确恢复）
        if (MODE_LIGHT.equals(getMode(a))) {
            if (t.getTag(R.id.theme_orig_text) == null) {
                t.setTag(R.id.theme_orig_text, cur);
            }
            return 0xFF000000;
        }
        if (isTextKey(cur, a)) {
            t.setTag(R.id.theme_orig_text, cur);
            return mapText(cur, a, p);
        }
        Integer tag = (Integer) t.getTag(R.id.theme_orig_text);
        if (tag != null) return mapText(tag, a, p);
        return cur;
    }

    private static Integer resolveBg(View v, int cur, Activity a, int[] p) {
        if (isBgKey(cur, a)) {
            v.setTag(R.id.theme_orig_bg, cur);
            return mapBg(cur, a, p);
        }
        Integer tag = (Integer) v.getTag(R.id.theme_orig_bg);
        if (tag != null) return mapBg(tag, a, p);
        return null;
    }

    private static int resolveTint(View v, int cur, Activity a, int[] p) {
        if (isTintKey(cur, a)) {
            v.setTag(R.id.theme_orig_tint, cur);
            return mapTint(cur, a, p);
        }
        Integer tag = (Integer) v.getTag(R.id.theme_orig_tint);
        if (tag != null) return mapTint(tag, a, p);
        return 0;
    }

    private static boolean isTextKey(int cur, Activity a) {
        return cur == key(a, R.color.primary_text)
                || cur == key(a, R.color.secondary_text)
                || cur == key(a, R.color.hint_text)
                || cur == key(a, R.color.button_text)
                || cur == key(a, R.color.on_primary_text)
                || cur == key(a, R.color.novel_text)
                || cur == key(a, R.color.primary_color);
    }

    private static boolean isBgKey(int cur, Activity a) {
        return cur == key(a, R.color.background)
                || cur == key(a, R.color.header_bar)
                || cur == key(a, R.color.surface);
    }

    private static boolean isTintKey(int cur, Activity a) {
        return cur == key(a, R.color.primary_color)
                || cur == key(a, R.color.primary_dark)
                || cur == key(a, R.color.secondary_color)
                || cur == key(a, R.color.accent_color)
                || cur == key(a, R.color.surface)
                || cur == key(a, R.color.surface_soft)
                || cur == key(a, R.color.error);
    }

    private static boolean isHeaderGradient(View v, Activity a) {
        Boolean tag = (Boolean) v.getTag(R.id.theme_is_header);
        if (tag == null) {
            Drawable d = v.getBackground();
            Drawable hg = a.getResources().getDrawable(R.drawable.header_gradient, a.getTheme());
            tag = d != null && hg != null
                    && d.getConstantState() != null
                    && d.getConstantState().equals(hg.getConstantState());
            v.setTag(R.id.theme_is_header, tag);
        }
        return tag;
    }

    // ---- 映射（原始色 -> 当前主题目标色）----

    private static int mapText(int cur, Activity a, int[] p) {
        if (cur == key(a, R.color.primary_text)) return p[P_TEXT];
        if (cur == key(a, R.color.secondary_text)) return p[P_TEXT_SEC];
        if (cur == key(a, R.color.hint_text)) return p[P_HINT];
        if (cur == key(a, R.color.button_text)) return p[P_ON_ACCENT];
        if (cur == key(a, R.color.on_primary_text)) return p[P_ON_PRIMARY];
        if (cur == key(a, R.color.novel_text)) return p[P_NOVEL];
        if (cur == key(a, R.color.primary_color)) return p[P_ACCENT];
        return cur;
    }

    private static Integer mapBg(int cur, Activity a, int[] p) {
        // 液态玻璃：页面底色/顶栏全部透明，让窗口壁纸透出来
        if (cur == key(a, R.color.background)) return Color.TRANSPARENT;
        if (cur == key(a, R.color.header_bar)) return Color.TRANSPARENT;
        if (cur == key(a, R.color.surface)) return p[P_CARD];
        return null;
    }

    private static int mapTint(int cur, Activity a, int[] p) {
        if (cur == key(a, R.color.primary_color)) return p[P_ACCENT];
        if (cur == key(a, R.color.primary_dark)) return p[P_ACCENT_DARK];
        if (cur == key(a, R.color.secondary_color)) return p[P_SECONDARY];
        if (cur == key(a, R.color.accent_color)) return p[P_ACCENT2];
        if (cur == key(a, R.color.surface)) return p[P_CARD];
        if (cur == key(a, R.color.surface_soft)) return p[P_CARD_SOFT];
        if (cur == key(a, R.color.error)) return p[P_ERROR];
        return 0;
    }

    private static int key(Activity a, int res) {
        return a.getResources().getColor(res);
    }

    /**
     * 调色板。暗黑 = 当前 colors.xml 资源值（保持不变）；
     * 明亮 = 3.8.3 原始配色；自定义 = 用户背景色 + 文字色推导。
     */
    private static int[] palette(Activity a) {
        String mode = getMode(a);
        if (MODE_LIGHT.equals(mode)) {
            // 明亮：纯白背景
            return new int[]{
                    0xFFFFFFFF, // BG background
                    0xFFFFFFFF, // CARD surface
                    0xFFF5F5F5, // CARD_SOFT surface_soft
                    0xFF000000, // TEXT primary_text
                    0xFF333333, // TEXT_SEC secondary_text
                    0xFF666666, // HINT hint_text
                    0xFF93B590, // ACCENT primary_color
                    0xFF6E8A6C, // ACCENT_DARK primary_dark
                    0xFFA9C0A7, // SECONDARY secondary_color
                    0xFF7E9B7B, // ACCENT2 accent_color
                    0xFF000000, // ON_ACCENT button_text
                    0xFFFFFFFF, // HEADER header_bar
                    0xFFA8504C, // ERROR error
                    0xFF000000, // ON_PRIMARY on_primary_text
                    0xFF000000  // NOVEL novel_text
            };
        }
        if (MODE_CUSTOM.equals(mode)) {
            int bg = getBg(a);
            int tx = getText(a);
            return new int[]{
                    bg,
                    blend(bg, tx, 0.08f),
                    blend(bg, tx, 0.14f),
                    tx,
                    blend(tx, bg, 0.35f),
                    blend(tx, bg, 0.50f),
                    0xFFC9A961,
                    0xFFA8843C,
                    0xFF4A90E2,
                    0xFFC9A961,
                    0xFF121212,
                    blend(bg, tx, 0.06f),
                    0xFFE57373,
                    tx,
                    tx
            };
        }
        // 暗黑（默认）：纯黑背景
        return new int[]{
                0xFF000000, // BG
                0xFF0A0A0A, // CARD
                0xFF141414, // CARD_SOFT
                0xFFF5F5F5, // TEXT
                0xFFB0B0B0, // TEXT_SEC
                0xFF7A7A7A, // HINT
                0xFFC9A961, // ACCENT
                0xFFA8843C, // ACCENT_DARK
                0xFF4A90E2, // SECONDARY
                0xFFC9A961, // ACCENT2
                0xFF121212, // ON_ACCENT
                0xFF000000, // HEADER
                0xFFE57373, // ERROR
                0xFFF5F5F5, // ON_PRIMARY
                0xFFE8E8E8  // NOVEL
        };
    }

    private static int blend(int a, int b, float f) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = Math.round(ar + (br - ar) * f);
        int g = Math.round(ag + (bg - ag) * f);
        int bl = Math.round(ab + (bb - ab) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** 解析 "#RRGGBB" 或 "RRGGBB"；失败返回 fallback。 */
    public static int parseColor(String s, int fallback) {
        if (s == null) return fallback;
        s = s.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (s.length() != 6) return fallback;
        try {
            return 0xFF000000 | Integer.parseInt(s, 16);
        } catch (Exception e) {
            return fallback;
        }
    }

    public static String toHex(int color) {
        return String.format("#%06X", 0xFFFFFF & color);
    }
}

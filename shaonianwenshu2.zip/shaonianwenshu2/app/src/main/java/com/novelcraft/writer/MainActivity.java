package com.novelcraft.writer;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import com.example.liquidglass.LiquidGlassButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;
import android.media.MediaPlayer;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.animation.ValueAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;

import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import com.novelcraft.writer.NovelService.NovelCallback;
import com.novelcraft.writer.NovelService.Chapter;
import com.novelcraft.writer.NovelService.Params;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends android.app.Activity {

    private EditText etTitle, etStyle, etChapterTitle, etTotalChapters, etHeroName, etMainContent, etContextSummary;
    private com.example.liquidglass.LiquidGlassChip cbUseSummary;
    private Spinner spinnerGenre;
    private com.example.liquidglass.LiquidGlassSlider sliderChapterLen;
    private LiquidGlassButton btnStart, btnStart2, btnContinue, btnSave, btnCopy, btnShare, btnClear, btnReview, btnSort, btnStop;
    private ProgressBar progressBar, progressCard;
        private TextView tvProgress, tvStatus, tvChapterHeader, tvCardTitle, tvCardGenre, tvCardProgress, tvCardScore, tvProgressPct;
    private ListView chapterList;
    private ScrollView outerScroll;

    private NovelService service;
    private final StringBuilder novel = new StringBuilder();
    private NotificationManager mNotifyManager;
    private static final int NOTIFY_ID_GENERATE = 1001;
    private MediaPlayer mClickPlayer;
    private final List<Chapter> allChapters = new ArrayList<>();
    private File currentLibDir;
    private String outlineText = "";
    private String settingsText = "";
    private android.content.SharedPreferences editorPrefs;
    private boolean busy = false;
    private int aiScore = 0;
    private ImageView imgQianli;
    private ValueAnimator qianliAnim;
    private float qianliTx = 0f;

    private static final int REQ_PERMISSION_STORAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ThemeManager.apply(this);

        service = new NovelService(this);
        editorPrefs = getSharedPreferences("editor_prefs", MODE_PRIVATE);
        bindViews();
        setupSpinners();
        restoreEditor();
        setupActions();
        setupBottomNav();
        createNotificationChannel();
        checkNotificationPermission();
        updateStatus();
        handleIntentAction(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntentAction(intent);
    }

    private void handleIntentAction(Intent intent) {
        if (intent == null) return;
        String action = intent.getStringExtra("action");
        if (action == null) return;
        intent.removeExtra("action");
        if ("factory".equals(action)) {
            scrollToWorkbench();
        } else if ("quality".equals(action)) {
            reviewCurrent();
        } else if ("outline".equals(action)) {
            generateOutline();
        } else if ("chat".equals(action)) {
            openChat();
        } else if ("review".equals(action)) {
            reviewCurrent();
        } else if ("batch".equals(action)) {
            showBatchDialog();
        }
    }

    private void bindViews() {
        etTitle = findViewById(R.id.etTitle);
        etStyle = findViewById(R.id.etStyle);
        etChapterTitle = findViewById(R.id.etChapterTitle);
        etTotalChapters = findViewById(R.id.etTotalChapters);
        etHeroName = findViewById(R.id.etHeroName);
        etMainContent = findViewById(R.id.etMainContent);
        etContextSummary = findViewById(R.id.etContextSummary);
        cbUseSummary = findViewById(R.id.cbUseSummary);
        spinnerGenre = findViewById(R.id.spinnerGenre);
        sliderChapterLen = findViewById(R.id.sliderChapterLen);
        btnStart = findViewById(R.id.btnStart);
        btnStart2 = findViewById(R.id.btnStart2);
        btnContinue = findViewById(R.id.btnContinue);
        btnSave = findViewById(R.id.btnSave);
        btnCopy = findViewById(R.id.btnCopy);
        btnShare = findViewById(R.id.btnShare);
        btnClear = findViewById(R.id.btnClear);
        btnReview = findViewById(R.id.btnReview);
        btnSort = findViewById(R.id.btnSort);
        btnStop = findViewById(R.id.btnStop);
        progressBar = findViewById(R.id.progressBar);
        tvProgressPct = findViewById(R.id.tvProgressPct);
        tvProgress = findViewById(R.id.tvProgress);
        tvStatus = findViewById(R.id.tvStatus);
        tvChapterHeader = findViewById(R.id.tvChapterHeader);
        chapterList = findViewById(R.id.chapterList);
        outerScroll = findViewById(R.id.outerScroll);
        tvCardTitle = findViewById(R.id.tvCardTitle);
        tvCardGenre = findViewById(R.id.tvCardGenre);
        tvCardProgress = findViewById(R.id.tvCardProgress);
        progressCard = findViewById(R.id.progressCard);
        tvCardScore = findViewById(R.id.tvCardScore);
        imgQianli = findViewById(R.id.imgQianli);
        findViewById(R.id.btnStartCreate).setOnClickListener(v -> { playClickSound(); startChapter(true, 1); });
        findViewById(R.id.btnStart2).setOnClickListener(v -> { playClickSound(); startChapter(true, 1); });
        chapterList.setOnItemClickListener((parent, view, position, id) -> openChapter(position));
        btnSort.setOnClickListener(v -> { playClickSound(); sortChapters(); });
        btnStop.setOnClickListener(v -> { playClickSound(); stopGeneration(); });
        findViewById(R.id.btnEditNovel).setOnClickListener(v -> { playClickSound(); openCreationSettings(); });
        findViewById(R.id.btnToggleSettings).setOnClickListener(v -> { playClickSound(); openCreationSettings(); });
        findViewById(R.id.btnWorkbench).setOnClickListener(v -> { playClickSound(); startActivity(new Intent(this, WorkbenchActivity.class)); });
    }

    private void generateSummary() {
        if (novel.length() == 0) {
            toast(R.string.summary_empty);
            return;
        }
        if (!service.hasValidApiKey()) {
            toast(R.string.error_api_key);
            return;
        }
        toast(R.string.summary_generating);
        service.summarize(novel.toString(), new NovelService.NovelCallback() {
            @Override
            public void onStatus(String status) {
            }

            @Override
            public void onContent(String fullText, boolean done) {
                if (done) {
                    etContextSummary.setText(fullText);
                    toast(R.string.summary_done);
                }
            }

            @Override
            public void onError(String error) {
                toast(error);
            }
        });
    }

    private void openCreationSettings() {
        startActivityForResult(new Intent(this, CreationSettingsActivity.class), REQ_CREATION_SETTINGS);
    }

    private void scrollToWorkbench() {
        // 工作台已独立成页，无需滚动
    }

    private static final int REQ_LIBRARY = 200;
    private static final int REQ_REVIEW = 201;
    private static final int REQ_CHAT = 202;
    private static final int REQ_CREATION_SETTINGS = 203;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_LIBRARY) {
            if (resultCode == RESULT_OK && data != null) {
                String title = data.getStringExtra("title");
                String content = data.getStringExtra("content");
                String dir = data.getStringExtra("dir");
                currentLibDir = dir == null ? null : new File(dir);
                if (title != null && content != null) {
                    loadNovel(title, content,
                            data.getStringExtra("genre"),
                            data.getStringExtra("style"),
                            data.getIntExtra("chapterLength", -1),
                            data.getIntExtra("totalChapters", 0));
                }
            } else if (resultCode == LibraryActivity.RESULT_NEW) {
                newNovel();
            }
        } else if (requestCode == REQ_REVIEW && resultCode == RESULT_OK && data != null) {
            try {
            if (allChapters == null || allChapters.isEmpty()) {
                doReview(novelTitle(), novel.toString(), null, false);
                return;
            }
            int[] indices = data.getIntArrayExtra("indices");
            boolean autoRevise = data.getBooleanExtra("autoRevise", false);
            StringBuilder sb = new StringBuilder();
            String prefix = novelTitle();
            if (indices != null) {
                for (int idx : indices) {
                    if (idx < 0 || idx >= allChapters.size()) continue;
                    Chapter c = allChapters.get(idx);
                    if (c == null) continue;
                    String t = c.title == null ? ("第 " + (idx + 1) + " 章") : c.title;
                    String cContent = c.content == null ? "" : c.content;
                    sb.append(t).append("\n\n").append(cContent).append("\n\n");
                }
            }
            String content = sb.toString().trim();
            if (content.isEmpty()) {
                content = novel.toString();
            }
            doReview(prefix, content, indices, autoRevise);
            } catch (Exception e) {
                android.util.Log.e("MainActivity", "评审结果处理失败", e);
                toast("评审结果处理失败：" + e.getMessage());
            }
        } else if (requestCode == REQ_CHAT) {
            if (currentLibDir != null) {
                allChapters.clear();
                allChapters.addAll(SaveHelper.loadChapters(currentLibDir));
                refreshChapterList();
                updateStatus();
            }
        } else if (requestCode == REQ_CREATION_SETTINGS && resultCode == RESULT_OK) {
            restoreEditor();
            updateStatus();
        }
    }

    private void loadNovel(String title, String content, String genre, String style,
                           int chapterLength, int totalChapters) {
        etTitle.setText(title);
        etTitle.setSelection(etTitle.getText().length());
        applySettings(genre, style, chapterLength, totalChapters);
        etHeroName.setText(currentLibDir == null ? "" : SaveHelper.getHeroName(currentLibDir));
        novel.setLength(0);
        novel.append(content);
        allChapters.clear();
        if (currentLibDir != null) {
            allChapters.addAll(SaveHelper.loadChapters(currentLibDir));
            outlineText = SaveHelper.getOutline(currentLibDir);
            settingsText = SaveHelper.getSettings(currentLibDir);
            etHeroName.setText(SaveHelper.getHeroName(currentLibDir));
            etMainContent.setText(SaveHelper.getMainContent(currentLibDir));
        } else {
            allChapters.addAll(SaveHelper.splitChapters(content));
            outlineText = "";
            settingsText = "";
        }
        refreshChapterList();
        updateStatus();
        toast("已载入《" + title + "》，点“续写下一章”继续创作");
    }

    private void newNovel() {
        currentLibDir = null;
        allChapters.clear();
        novel.setLength(0);
        outlineText = "";
        settingsText = "";
        etTitle.setText("");
        etChapterTitle.setText("");
        etTotalChapters.setText("");
        etHeroName.setText("");
        etMainContent.setText("");
        refreshChapterList();
        updateStatus();
    }

    private void setupBottomNav() {
        GlassNav.setup(this, 0, index -> {
        playClickSound();
        if (index == 1) {
            startActivityForResult(new Intent(this, LibraryActivity.class), REQ_LIBRARY);
        } else if (index == 2) {
            startActivity(new Intent(this, CreationSettingsActivity.class));
        } else if (index == 3) {
            openSettings();
        }
        });
    }

    private void setupSpinners() {
        spinnerGenre.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                split(getString(R.string.genres))));
        // 单章字数：液态玻璃滑块（档位来自 chapter_lengths）
        List<String> parts = split(getString(R.string.chapter_lengths));
        int[] lens = new int[parts.size()];
        for (int i = 0; i < parts.size(); i++) {
            lens[i] = Integer.parseInt(parts.get(i).trim());
        }
        sliderChapterLen.setUnit(getString(R.string.unit_zi));
        sliderChapterLen.setValues(lens);
    }

    private void restoreEditor() {
        try {
            etTitle.setText(editorPrefs.getString("novel_title", ""));
            selectSpinnerValue(spinnerGenre, editorPrefs.getString("genre", ""));
            etStyle.setText(editorPrefs.getString("style", ""));
            int len = editorPrefs.getInt("chapterLength", -1);
            if (len > 0) {
                sliderChapterLen.setValue(len);
            }
            int tot = editorPrefs.getInt("totalChapters", 0);
            if (tot > 0) etTotalChapters.setText(String.valueOf(tot));
            etHeroName.setText(editorPrefs.getString("heroName", ""));
            etMainContent.setText(editorPrefs.getString("mainContent", ""));
            etContextSummary.setText(editorPrefs.getString("contextSummary", ""));
            etChapterTitle.setText(editorPrefs.getString("chapterTitle", ""));
            cbUseSummary.setChecked(editorPrefs.getBoolean("useSummary", false));
            aiScore = editorPrefs.getInt("aiScore", 0);
        } catch (Exception ignored) {
        }
    }

    private void saveEditor() {
        try {
            editorPrefs.edit()
                    .putString("novel_title", etTitle.getText().toString().trim())
                    .putString("genre", selectedGenre())
                    .putString("style", selectedStyle())
                    .putInt("chapterLength", readChapterLength())
                    .putInt("totalChapters", readTotalChapters())
                    .putString("heroName", etHeroName.getText().toString().trim())
                    .putString("mainContent", etMainContent.getText().toString().trim())
                    .putString("contextSummary", etContextSummary.getText().toString().trim())
                    .putBoolean("useSummary", cbUseSummary.isChecked())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveEditor();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ThemeManager.apply(this);
        GlassNav.correct(this);
        restoreEditor();
        updateStatus();
    }

    private void setupActions() {
        btnStart.setOnClickListener(v -> { playClickSound(); startChapter(true, 1); });
        btnContinue.setOnClickListener(v -> { playClickSound(); startChapter(false, 1); });
        btnSave.setOnClickListener(v -> { playClickSound(); saveNovel(); });
        btnCopy.setOnClickListener(v -> { playClickSound(); copyNovel(); });
        btnShare.setOnClickListener(v -> { playClickSound(); shareNovel(); });
        btnClear.setOnClickListener(v -> { playClickSound(); clearNovel(); });
        btnReview.setOnClickListener(v -> { playClickSound(); reviewCurrent(); });
    }

    private void generateOutline() {
        String title = etTitle.getText().toString().trim();
        if (TextUtils.isEmpty(title)) {
            toast(R.string.error_title_empty);
            return;
        }
        if (!service.hasValidApiKey()) {
            int quota = getDemoQuota();
            if (quota <= 0) {
                toast(R.string.demo_quota_empty);
                return;
            }
            consumeDemoQuota(quota - 1);
            final String outline = buildDemoOutline(title);
            setBusy(true);
            tvProgress.setText(R.string.demo_outline_generating);
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                setBusy(false);
                tvProgress.setText(R.string.progress_done);
                saveOutlineToStory(outline);
                openOutlineEditor();
                toast(getString(R.string.demo_quota_left, quota - 1));
            }, 600);
            return;
        }
        if (currentLibDir != null && !SaveHelper.getOutline(currentLibDir).isEmpty()) {
            openOutlineEditor();
            return;
        }
        Params p = new Params();
        p.title = title;
        p.genre = (String) spinnerGenre.getSelectedItem();
        p.style = etStyle.getText().toString().trim();
        p.totalChapters = readTotalChapters();
        p.heroName = etHeroName.getText().toString().trim();
        p.mainContent = etMainContent.getText().toString().trim();
        p.previousStory = novel.toString();
        setBusy(true);
        tvProgress.setText(R.string.toast_outlining);
        service.generateOutline(p, new NovelCallback() {
            @Override
            public void onStatus(String status) {
            }

            @Override
            public void onContent(String fullText, boolean done) {
                setBusy(false);
                if (done) {
                    tvProgress.setText(R.string.progress_done);
                    saveOutlineToStory(fullText);
                    openOutlineEditor();
                }
            }

            @Override
            public void onError(String error) {
                setBusy(false);
                tvProgress.setText(getString(R.string.progress_failed, error));
                showErrorDialog(error);
            }
        });
    }

    private void saveOutlineToStory(String outline) {
        outlineText = outline;
        String[] parts = SaveHelper.splitOutline(outline);
        settingsText = (parts[0] == null) ? "" : parts[0];
        try {
            currentLibDir = SaveHelper.saveOutline(this, novelTitle(), currentLibDir, outline);
            if (!settingsText.isEmpty()) {
                currentLibDir = SaveHelper.saveSettings(this, novelTitle(), currentLibDir, settingsText);
            }
            String n = etHeroName.getText().toString().trim();
            if (!TextUtils.isEmpty(n)) {
                currentLibDir = SaveHelper.saveHeroName(this, novelTitle(), currentLibDir, n);
            }
            String mc = etMainContent.getText().toString().trim();
            if (!TextUtils.isEmpty(mc)) {
                currentLibDir = SaveHelper.saveMainContent(this, novelTitle(), currentLibDir, mc);
            }
        } catch (Exception ignored) {
        }
    }

    private int getDemoQuota() {
        return getSharedPreferences("demo", MODE_PRIVATE).getInt("demo_quota", 5);
    }

    private void consumeDemoQuota(int v) {
        getSharedPreferences("demo", MODE_PRIVATE).edit().putInt("demo_quota", v).apply();
    }

    private String buildDemoOutline(String title) {
        int total = readTotalChapters();
        if (total < 1) total = 12;
        String genre = selectedGenre();
        String style = selectedStyle();
        StringBuilder sb = new StringBuilder();
        sb.append("《").append(title).append("》大纲\n");
        sb.append("题材：").append(genre == null || genre.isEmpty() ? "未定" : genre);
        sb.append("　风格：").append(style == null || style.isEmpty() ? "未定" : style);
        sb.append("\n\n【故事梗概】\n");
        sb.append("少年怀志，踏上一段追寻理想与成长的旅程。历经风雨与磨砺，主角逐渐领悟担当与坚守，以赤子之心书写属于自己的青春篇章。\n\n");
        sb.append("【章节大纲】\n");
        String[] arcs = {"缘起 · 少年立志", "入局 · 初涉风波", "波折 · 险象环生", "成长 · 明心见性", "淬炼 · 突破自我", "归心 · 少年有为"};
        for (int i = 1; i <= total; i++) {
            sb.append("第").append(i).append("章　").append(arcs[(i - 1) % arcs.length]).append("\n");
        }
        return sb.toString();
    }

    private void openOutlineEditor() {
        Intent it = new Intent(this, OutlineActivity.class);
        it.putExtra("title", etTitle.getText().toString().trim());
        it.putExtra("genre", selectedGenre());
        it.putExtra("style", selectedStyle());
        it.putExtra("totalChapters", readTotalChapters());
        it.putExtra("heroName", etHeroName.getText().toString().trim());
        if (currentLibDir != null) {
            it.putExtra("dir", currentLibDir.getAbsolutePath());
        }
        startActivity(it);
    }

    private void reviewCurrent() {
        try {
            if (service == null) {
                toast("服务未初始化，请重启应用");
                return;
            }
            if (novel == null || novel.length() == 0) {
                toast(R.string.review_empty);
                return;
            }
            if (!service.hasValidApiKey()) {
                toast(R.string.error_api_key);
                return;
            }
            if (allChapters == null || allChapters.isEmpty()) {
                doReview(novelTitle(), novel.toString(), null, false);
                return;
            }
            String[] titles = new String[allChapters.size()];
            for (int i = 0; i < allChapters.size(); i++) {
                Chapter c = allChapters.get(i);
                titles[i] = c == null ? "第 " + (i + 1) + " 章" : c.title;
            }
            Intent it = new Intent(this, ChapterSelectActivity.class);
            it.putExtra("titles", titles);
            startActivityForResult(it, REQ_REVIEW);
        } catch (Exception e) {
            android.util.Log.e("MainActivity", "AI 评审启动失败", e);
            toast("AI 评审启动失败：" + e.getMessage());
        }
    }

    private int[] pendingIndices;
    private boolean pendingAutoRevise = false;
    private int revisePos = 0;
    private String pendingReviewText = "";

    private void doReview(String title, String content) {
        doReview(title, content, null, false);
    }

    private void doReview(String title, String content, int[] indices, boolean autoRevise) {
        try {
            if (isFinishing()) return;
            if (service == null) {
                setBusy(false);
                toast("服务未初始化，请重启应用");
                return;
            }
            if (content == null) content = "";
            setBusy(true);
            tvProgress.setText(R.string.toast_reviewing);
            showReviewingNotification();
            service.review(title, content, new NovelCallback() {
            @Override
            public void onStatus(String status) {
            }

            @Override
            public void onContent(String fullText, boolean done) {
                if (isFinishing()) return;
                if (done) {
                    try {
                        int s = parseScore(fullText);
                        if (s > 0) {
                            aiScore = s;
                            if (editorPrefs != null) editorPrefs.edit().putInt("aiScore", s).apply();
                            updateStatus();
                        }
                        if (indices != null && currentLibDir != null && allChapters != null) {
                            for (int idx : indices) {
                                if (idx >= 0 && idx < allChapters.size()) {
                                    SaveHelper.updateChapterReview(currentLibDir, idx, fullText);
                                }
                            }
                        }
                        String safeText = fullText == null ? "" : fullText;
                        cancelGeneratingNotification();
                        playCompleteSound();
                        showTextResult(getString(R.string.review_title), safeText);
                        if (autoRevise && indices != null && indices.length > 0) {
                            startAutoRevise(safeText, indices);
                        } else {
                            setBusy(false);
                            tvProgress.setText(R.string.progress_done);
                        }
                    } catch (Exception e) {
                        setBusy(false);
                        android.util.Log.e("MainActivity", "评审回调处理失败", e);
                        toast("评审回调失败：" + e.getMessage());
                    }
                }
            }

            @Override
            public void onError(String error) {
                if (isFinishing()) return;
                cancelGeneratingNotification();
                playCompleteSound();
                setBusy(false);
                tvProgress.setText(getString(R.string.progress_failed, error));
                showErrorDialog(error);
            }
        });
        } catch (Exception e) {
            cancelGeneratingNotification();
            playCompleteSound();
            setBusy(false);
            android.util.Log.e("MainActivity", "AI 评审执行失败", e);
            toast("AI 评审失败：" + e.getMessage());
        }
    }

    private void startAutoRevise(String review, int[] indices) {
        if (isFinishing()) return;
        pendingIndices = indices;
        pendingReviewText = review;
        revisePos = 0;
        tvProgress.setText(getString(R.string.auto_revise_working, 0, indices.length));
        reviseNext();
    }

    private void reviseNext() {
        if (isFinishing()) return;
        if (pendingIndices == null || revisePos >= pendingIndices.length) {
            setBusy(false);
            tvProgress.setText(R.string.progress_done);
            toast(getString(R.string.auto_revise_done, revisePos));
            if (currentLibDir != null) {
                allChapters.clear();
                allChapters.addAll(SaveHelper.loadChapters(currentLibDir));
                refreshChapterList();
            }
            return;
        }
        final int idx = pendingIndices[revisePos];
        if (idx < 0 || idx >= allChapters.size()) {
            revisePos++;
            reviseNext();
            return;
        }
        final Chapter c = allChapters.get(idx);
        tvProgress.setText(getString(R.string.auto_revise_working, revisePos + 1, pendingIndices.length));
        if (service == null) {
            setBusy(false);
            toast("服务未初始化，请重启应用");
            return;
        }
        service.reviseChapter(novelTitle(),
                etHeroName.getText().toString().trim(),
                etMainContent.getText().toString().trim(),
                outlineText, c.title, c.content, pendingReviewText,
                new NovelService.ChatCallback() {
                    @Override
                    public void onReply(String reply) {
                        if (isFinishing()) return;
                        try {
                            String cleaned = reply == null ? "" : reply.trim();
                            if (!cleaned.isEmpty()) {
                                allChapters.set(idx, new Chapter(c.title, cleaned));
                                if (currentLibDir != null) {
                                    SaveHelper.updateChapter(currentLibDir, idx, cleaned);
                                }
                            }
                        } catch (Exception e) {
                            android.util.Log.e("MainActivity", "自动修改回复处理失败", e);
                        }
                        revisePos++;
                        reviseNext();
                    }

                    @Override
                    public void onError(String error) {
                        if (isFinishing()) return;
                        setBusy(false);
                        tvProgress.setText(getString(R.string.auto_revise_failed, error));
                        toast(getString(R.string.auto_revise_failed, error));
                    }
                });
    }

    private void showTextResult(String title, String text) {
        Intent it = new Intent(this, ChapterContentActivity.class);
        it.putExtra("title", title);
        it.putExtra("content", text);
        startActivity(it);
    }

    private void startChapter(boolean first, int batchCount) {
        String title = etTitle.getText().toString().trim();
        if (TextUtils.isEmpty(title)) {
            toast(R.string.error_title_empty);
            return;
        }
        if (!service.hasValidApiKey()) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle(R.string.api_key_needed_title)
                    .setMessage(R.string.api_key_needed_msg)
                    .setPositiveButton(R.string.go_settings, (d, w) -> openSettings())
                    .setNegativeButton(R.string.btn_cancel, null)
                    .show();
            return;
        }
        if (first) {
            currentLibDir = null;
            allChapters.clear();
        }
        Params p = new Params();
        p.title = title;
        p.genre = (String) spinnerGenre.getSelectedItem();
        p.style = etStyle.getText().toString().trim();
        p.chapterLength = readChapterLength();
        if (!VipManager.isVip(this) && p.chapterLength > VipManager.FREE_MAX_CHAPTER_LENGTH) {
            p.chapterLength = VipManager.FREE_MAX_CHAPTER_LENGTH;
            toast(R.string.vip_chapter_clamped);
        }
        p.totalChapters = readTotalChapters();
        p.chapterTitle = etChapterTitle.getText().toString().trim();
        p.isFirst = first;
        p.batchCount = batchCount;
        p.outline = outlineText;
        p.settings = settingsText;
        p.heroName = etHeroName.getText().toString().trim();
        p.mainContent = etMainContent.getText().toString().trim();
        p.contextSummary = cbUseSummary.isChecked() ? etContextSummary.getText().toString().trim() : "";
        p.startChapterNumber = first ? 1 : nextChapterNumber();
        if (!first) {
            p.previousStory = boundStory(novel.toString());
        }

        setBusy(true);
        showGeneratingNotification();
        progressBar.setIndeterminate(false);
        progressBar.setMax(batchCount);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.VISIBLE);
        LinearLayout pctWrap = (LinearLayout) progressBar.getParent();
        if (pctWrap != null) pctWrap.setVisibility(View.VISIBLE);
        startQianliPan();
        service.generate(p, new NovelCallback() {
            @Override
            public void onStatus(String status) {
                tvProgress.setText(status);
                // 状态格式："连载 1/3 ｜ 第 1 章"
                int slash = status.indexOf('/');
                if (slash > 0) {
                    try {
                        int end = slash;
                        int start = status.lastIndexOf(' ', end - 1);
                        if (start < 0) start = 0;
                        int cur = Integer.parseInt(status.substring(start + 1, end).trim());
                        if (cur > 0 && cur <= batchCount) {
                            progressBar.setProgress(cur);
                            tvProgressPct.setText(String.format(Locale.getDefault(), "%d/%d 章", cur, batchCount));
                        }
                    } catch (Exception ignored) {}
                }
            }

            @Override
            public void onContent(String fullText, boolean done) {
                novel.setLength(0);
                novel.append(fullText);
                if (done && novel.length() > 0) {
                    java.util.List<Chapter> added = new java.util.ArrayList<>(service.getLastChapters());
                    allChapters.addAll(added);
                    java.util.List<Chapter> bad = new java.util.ArrayList<>();
                    StringBuilder words = new StringBuilder();
                    for (Chapter c : added) {
                        java.util.List<String> h = ContentFilter.check(c.content);
                        if (!h.isEmpty()) {
                            bad.add(c);
                            for (String w : h) {
                                if (words.indexOf(w) < 0) words.append(w).append(" ");
                            }
                        }
                    }
                    updateStatus();
                    finishProgress(true);
                    if (!bad.isEmpty()) {
                        allChapters.removeAll(bad);
                        showFilterDialog(words.toString().trim());
                    } else {
                        autoSaveToLibrary();
                    }
                } else {
                    updateStatus();
                }
                if (done) {
                    refreshChapterList();
                    sortChapters(true);
                }
            }

            private void showFilterDialog(String words) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle(R.string.filter_title)
                        .setMessage(getString(R.string.filter_msg, words))
                        .setPositiveButton(R.string.btn_ok, null)
                        .show();
            }

            @Override
            public void onError(String error) {
                finishProgress(false);
                tvProgress.setText(getString(R.string.progress_failed, error));
                toastLong(error);
                showErrorDialog(error);
            }
        });
    }

    private void refreshChapterList() {
        if (chapterList == null) return;
        List<String> titles = new ArrayList<>();
        for (Chapter c : allChapters) {
            titles.add(c.title);
        }
        chapterList.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, titles));
        tvChapterHeader.setText(getString(R.string.chapter_list_title) + "  ·  " + allChapters.size() + " 章");
    }

    private String boundStory(String story) {
        if (story == null) return "";
        int max = 14000;
        return story.length() > max ? "……" + story.substring(story.length() - max) : story;
    }

    private int chapterNum(String t) {
        if (t == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("第\\s*(\\d+)\\s*章").matcher(t);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    /** 下一章编号 = 最小的缺失章号（可自动补回丢失的章节），没有缺失则取最大章号 + 1。 */
    private int nextChapterNumber() {
        java.util.Set<Integer> used = new java.util.HashSet<>();
        int max = 0;
        for (Chapter c : allChapters) {
            int n = chapterNum(c.title);
            if (n > 0) {
                used.add(n);
                if (n > max) max = n;
            }
        }
        if (used.isEmpty()) return allChapters.size() + 1;
        for (int n = 1; n <= max + 1; n++) {
            if (!used.contains(n)) return n;
        }
        return max + 1;
    }

    private void sortChapters() {
        sortChapters(false);
    }

    private void sortChapters(boolean quiet) {
        allChapters.sort((a, b) -> {
            int na = chapterNum(a.title), nb = chapterNum(b.title);
            if (na >= 0 && nb >= 0) return Integer.compare(na, nb);
            return a.title.compareTo(b.title);
        });
        refreshChapterList();
        if (!quiet) toast(R.string.chap_sort_done);
    }

    private void openChapter(int position) {
        if (position < 0 || position >= allChapters.size()) return;
        Chapter c = allChapters.get(position);
        showTextResult(c.title, c.content);
    }

    private void openChat() {
        Intent it = new Intent(this, ChatActivity.class);
        it.putExtra("title", etTitle.getText().toString().trim());
        if (currentLibDir != null) {
            it.putExtra("dir", currentLibDir.getAbsolutePath());
        }
        startActivityForResult(it, REQ_CHAT);
    }

    private void showErrorDialog(String error) {
        String raw = service.getLastRawResponse();
        if (raw.length() > 1200) {
            raw = raw.substring(0, 1200) + "…";
        }
        String detail = error + "\n\n[HTTP " + service.getLastHttpCode() + "]\n原始响应：\n" + raw;
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.dialog_error_title)
                .setMessage(detail)
                .setPositiveButton(R.string.btn_copy, (d, w) -> {
                    android.content.ClipboardManager cm =
                            (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("err", detail));
                    toast(R.string.copied);
                })
                .setNegativeButton(R.string.btn_close, null)
                .show();
    }

    private void showBatchDialog() {
        if (!VipManager.isVip(this)) {
            toast(R.string.vip_feature_locked);
            VipManager.openVipPage(this);
            return;
        }
        String[] counts = {"3 章", "5 章", "10 章"};
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.btn_batch)
                .setItems(counts, (dialog, which) -> {
                    int n = 3 + which * 2 + ((which == 2) ? 5 : 0);
                    startChapter(novel.length() == 0, n);
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    private void finishProgress(boolean success) {
        setBusy(false);
        stopQianliPan();
        cancelGeneratingNotification();
        progressBar.setIndeterminate(false);
        progressBar.setVisibility(ProgressBar.GONE);
        LinearLayout pctWrap = (LinearLayout) progressBar.getParent();
        if (pctWrap != null) pctWrap.setVisibility(View.GONE);
        tvProgressPct.setText("");
        if (success) {
            tvProgress.setText(R.string.progress_done);
            playCompleteSound();
        } else {
            tvProgress.setText(R.string.progress_waiting);
        }
    }

    private void createNotificationChannel() {
        mNotifyManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (mNotifyManager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    getString(R.string.notification_channel_id),
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(getString(R.string.notification_channel_desc));
            channel.enableLights(true);
            channel.enableVibration(true);
            mNotifyManager.createNotificationChannel(channel);
        }
    }

    private void showGeneratingNotification() {
        if (mNotifyManager == null) return;
        Notification.Builder builder = new Notification.Builder(this,
                getString(R.string.notification_channel_id))
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(getString(R.string.notification_generating_title))
                .setContentText(getString(R.string.notification_generating_content))
                .setOngoing(true)
                .setAutoCancel(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(getString(R.string.notification_channel_id));
        }
        mNotifyManager.notify(NOTIFY_ID_GENERATE, builder.build());
    }

    private void showReviewingNotification() {
        if (mNotifyManager == null) return;
        Notification.Builder builder = new Notification.Builder(this,
                getString(R.string.notification_channel_id))
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(getString(R.string.notification_reviewing_title))
                .setContentText(getString(R.string.notification_reviewing_content))
                .setOngoing(true)
                .setAutoCancel(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(getString(R.string.notification_channel_id));
        }
        mNotifyManager.notify(NOTIFY_ID_GENERATE, builder.build());
    }

    private void cancelGeneratingNotification() {
        if (mNotifyManager != null) {
            mNotifyManager.cancel(NOTIFY_ID_GENERATE);
        }
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1002);
            }
        }
    }

    private void playCompleteSound() {
        try {
            MediaPlayer mp = MediaPlayer.create(this, R.raw.complete_sound);
            if (mp != null) {
                mp.setOnCompletionListener(m -> m.release());
                mp.start();
            }
        } catch (Exception ignored) {
        }
    }

    private void playClickSound() {
        try {
            if (mClickPlayer != null) {
                mClickPlayer.release();
                mClickPlayer = null;
            }
            mClickPlayer = MediaPlayer.create(this, R.raw.click_sound);
            if (mClickPlayer != null) {
                mClickPlayer.setOnCompletionListener(m -> {
                    m.release();
                    mClickPlayer = null;
                });
                mClickPlayer.start();
            }
        } catch (Exception ignored) {
        }
    }

    private void setBusy(boolean b) {
        busy = b;
        btnStart.setEnabled(!b);
        btnContinue.setEnabled(!b);
        progressBar.setVisibility(b ? ProgressBar.VISIBLE : ProgressBar.GONE);
        btnStop.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private void initQianliMatrix() {
        if (imgQianli == null) return;
        Drawable d = imgQianli.getDrawable();
        int vw = imgQianli.getWidth();
        int vh = imgQianli.getHeight();
        if (d == null || vw <= 0 || vh <= 0) return;
        int iw = d.getIntrinsicWidth();
        int ih = d.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) return;
        float scale = (float) vh / ih;
        Matrix m = new Matrix();
        m.setScale(scale, scale);
        qianliTx = 0f;
        imgQianli.setImageMatrix(m);
    }

    private void startQianliPan() {
        if (imgQianli == null) return;
        if (qianliAnim != null) qianliAnim.cancel();
        imgQianli.post(new Runnable() {
            int retries = 0;
            @Override
            public void run() {
                initQianliMatrix();
                Drawable d = imgQianli.getDrawable();
                if (d == null) return;
                int vw = imgQianli.getWidth();
                int vh = imgQianli.getHeight();
                int ih = d.getIntrinsicHeight();
                if (vw <= 0 || vh <= 0 || ih <= 0) {
                    if (retries++ < 10) imgQianli.postDelayed(this, 100);
                    return;
                }
                float scale = (float) vh / ih;
                float scaledW = d.getIntrinsicWidth() * scale;
                float panMax = Math.max(0f, scaledW - vw);
                if (panMax <= 0) panMax = vw * 0.5f;
                qianliAnim = ValueAnimator.ofFloat(qianliTx, -panMax);
                qianliAnim.setDuration(12000);
                qianliAnim.setInterpolator(new LinearInterpolator());
                qianliAnim.addUpdateListener(a -> {
                    qianliTx = (float) a.getAnimatedValue();
                    Matrix m = new Matrix();
                    m.setScale(scale, scale);
                    m.postTranslate(qianliTx, 0f);
                    imgQianli.setImageMatrix(m);
                });
                qianliAnim.start();
            }
        });
    }

    private void stopQianliPan() {
        if (qianliAnim != null) {
            qianliAnim.cancel();
            qianliAnim = null;
        }
        if (imgQianli == null) return;
        imgQianli.post(() -> {
            Drawable d = imgQianli.getDrawable();
            int vw = imgQianli.getWidth();
            int vh = imgQianli.getHeight();
            if (d == null || vw <= 0 || vh <= 0) return;
            int ih = d.getIntrinsicHeight();
            if (ih <= 0) return;
            float scale = (float) vh / ih;
            ValueAnimator back = ValueAnimator.ofFloat(qianliTx, 0f);
            back.setDuration(500);
            back.setInterpolator(new OvershootInterpolator(2f));
            back.addUpdateListener(a -> {
                float tx = (float) a.getAnimatedValue();
                qianliTx = tx;
                Matrix m = new Matrix();
                m.setScale(scale, scale);
                m.postTranslate(tx, 0f);
                imgQianli.setImageMatrix(m);
            });
            back.start();
        });
    }

    private void stopGeneration() {
        if (service != null) service.cancel();
        setBusy(false);
        tvProgress.setText(R.string.progress_waiting);
        toast(R.string.toast_stopped);
    }

    private void updateStatus() {
        if (tvCardTitle != null) {
            String title = etTitle == null ? "" : etTitle.getText().toString().trim();
            tvCardTitle.setText(title.isEmpty() ? getString(R.string.novel_untitled) : title);
        }
        if (tvCardGenre != null) {
            String genre = selectedGenre();
            String style = selectedStyle();
            String g = genre == null || genre.isEmpty() ? getString(R.string.novel_no_genre) : genre;
            tvCardGenre.setText(style == null || style.isEmpty() ? g : (g + "  ·  " + style));
        }
        int done = allChapters.size();
        int total = readTotalChapters();
        if (tvCardProgress != null) {
            tvCardProgress.setText(getString(R.string.card_chapters, done,
                    total > 0 ? getString(R.string.card_total_suffix, total) : ""));
        }
        if (progressCard != null) {
            if (total > 0) {
                progressCard.setVisibility(View.VISIBLE);
                progressCard.setMax(total);
                progressCard.setProgress(Math.min(done, total));
            } else {
                progressCard.setVisibility(View.GONE);
            }
        }
        if (tvCardScore != null) {
            tvCardScore.setText(aiScore > 0 ? getString(R.string.card_score, aiScore) : getString(R.string.card_score_none));
        }
        int len = novel.length();
        tvStatus.setText(len > 0 ? getString(R.string.word_count, len) : "");
    }

    private int parseScore(String review) {
        if (review == null) return 0;
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?:综合)?总分[^0-9]{0,8}(\\d{1,3})").matcher(review);
            if (m.find()) {
                int v = Integer.parseInt(m.group(1));
                if (v >= 0 && v <= 100) return v;
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    private int readChapterLength() {
        return sliderChapterLen.getValue();
    }

    private void saveNovel() {
        if (novel.length() == 0) {
            toast(R.string.nothing_to_save);
            return;
        }
        if (Build.VERSION.SDK_INT < 29 && !hasStoragePermission()) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERMISSION_STORAGE);
            return;
        }
        doSave();
    }

    private void doSave() {
        final String t = novelTitle();
        final String text = novel.toString();
        final List<Chapter> chs = new ArrayList<>(allChapters);
        final int len = readChapterLength();
        final int total = readTotalChapters();
        final String g = selectedGenre();
        final String s = selectedStyle();
        new Thread(() -> {
            try {
                String where = SaveHelper.saveNovel(this, t, text);
                File d = SaveHelper.saveLibrary(this, t, chs, g, s, len, total, currentLibDir);
                currentLibDir = d;
                String hn = etHeroName.getText().toString().trim();
                if (!TextUtils.isEmpty(hn)) currentLibDir = SaveHelper.saveHeroName(this, t, currentLibDir, hn);
                String mc = etMainContent.getText().toString().trim();
                if (!TextUtils.isEmpty(mc)) currentLibDir = SaveHelper.saveMainContent(this, t, currentLibDir, mc);
                final String w = where;
                runOnUiThread(() -> toast(getString(R.string.saved_to) + "\n" + w));
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> toast(getString(R.string.saved_error, msg)));
            }
        }).start();
    }

    private void autoSaveToLibrary() {
        if (allChapters.isEmpty()) return;
        final String t = novelTitle();
        final int len = readChapterLength();
        final int total = readTotalChapters();
        final String g = selectedGenre();
        final String s = selectedStyle();
        final List<Chapter> chs = new ArrayList<>(allChapters);
        new Thread(() -> {
            try {
                File d = SaveHelper.saveLibrary(this, t, chs, g, s, len, total, currentLibDir);
                currentLibDir = d;
            } catch (Exception ignored) {
            }
        }).start();
    }

    private String formatChapters(List<Chapter> chapters) {
        StringBuilder sb = new StringBuilder();
        for (Chapter c : chapters) {
            if (sb.length() > 0) {
                sb.append("\n\n════════════════════\n\n");
            }
            sb.append(c.title).append("\n\n").append(c.content);
        }
        return sb.toString();
    }

    private int readTotalChapters() {
        try {
            int v = Integer.parseInt(etTotalChapters.getText().toString().trim());
            return Math.max(0, v);
        } catch (Exception e) {
            return 0;
        }
    }

    private String selectedGenre() {
        Object g = spinnerGenre.getSelectedItem();
        return g == null ? "" : g.toString();
    }

    private String selectedStyle() {
        return etStyle.getText().toString().trim();
    }

    private void applySettings(String genre, String style, int chapterLength, int totalChapters) {
        selectSpinnerValue(spinnerGenre, genre);
        etStyle.setText(style == null ? "" : style);
        if (chapterLength > 0) {
            sliderChapterLen.setValue(chapterLength);
        }
        etTotalChapters.setText(totalChapters > 0 ? String.valueOf(totalChapters) : "");
    }

    private void selectSpinnerValue(Spinner spinner, String value) {
        if (value == null) return;
        for (int i = 0; i < spinner.getAdapter().getCount(); i++) {
            if (value.equals(spinner.getAdapter().getItem(i))) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private void copyNovel() {
        if (novel.length() == 0) {
            toast(R.string.nothing_to_copy);
            return;
        }
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("novel", novel.toString()));
        toast(R.string.copied);
    }

    private void shareNovel() {
        if (novel.length() == 0) {
            toast(R.string.share_empty);
            return;
        }
        try {
            File f = SaveHelper.makeShareFile(this, novelTitle(), novel.toString());
            if (f == null) {
                toast(R.string.share_empty);
                return;
            }
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_STREAM,
                    FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".fileprovider", f));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, getString(R.string.btn_share)));
        } catch (Exception e) {
            toast(getString(R.string.saved_error, e.getMessage()));
        }
    }

    private void clearNovel() {
        if (novel.length() == 0) {
            toast(R.string.nothing_to_save);
            return;
        }
        new android.app.AlertDialog.Builder(this)
                .setMessage(R.string.clear_confirm)
                .setPositiveButton(R.string.btn_ok, (d, w) -> {
                    novel.setLength(0);
                    allChapters.clear();
                    refreshChapterList();
                    updateStatus();
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    private String novelTitle() {
        String t = etTitle.getText().toString().trim();
        return TextUtils.isEmpty(t) ? "无题" : t;
    }

    private void openSettings() {
        startActivity(new Intent(this, SettingsActivity.class));
    }

    private void toast(int resId) {
        Toast.makeText(this, resId, Toast.LENGTH_SHORT).show();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void toastLong(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private List<String> split(String src) {
        List<String> list = new ArrayList<>();
        if (src != null) {
            for (String s : src.split("\\|")) {
                if (!s.isEmpty()) list.add(s);
            }
        }
        return list;
    }

    private boolean hasStoragePermission() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSION_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                doSave();
            } else {
                toast(R.string.storage_denied);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            openSettings();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        service.shutdown();
    }
}

package com.novelcraft.writer;

import java.util.ArrayList;
import java.util.List;

/** 违禁词检测（涉黄 / 血腥 / 暴力）潜规则。 */
public class ContentFilter {

    private static final String[] WORDS = {
            // 涉黄
            "色情", "淫", "嫖娼", "卖淫", "强奸", "轮奸", "迷奸", "性奴", "裸体", "露点",
            "情色", "乱伦", "口交", "肛交", "自慰", "做爱", "性交", "肉棒", "阴道", "阴茎",
            "乳头", "援交", "约炮", "一夜情", "性行为", "黄文",
            // 血腥
            "血腥", "残肢", "断头", "割喉", "开膛", "肠子", "脑浆", "碎尸", "肢解",
            "血肉模糊", "血淋淋", "挖眼", "剥皮", "虐杀", "自残", "自杀", "食人",
            // 暴力
            "炸弹", "爆炸", "恐怖袭击", "枪支", "军火", "贩毒", "毒品", "冰毒", "海洛因",
            "杀人", "砍死", "捅死", "枪杀", "投毒", "绑架", "虐待", "凌迟",
    };

    /** 返回命中的违禁词（去重）。 */
    public static List<String> check(String text) {
        List<String> hits = new ArrayList<>();
        if (text == null || text.isEmpty()) return hits;
        for (String w : WORDS) {
            if (w != null && !w.isEmpty() && text.contains(w) && !hits.contains(w)) {
                hits.add(w);
            }
        }
        return hits;
    }

    public static boolean isClean(String text) {
        return check(text).isEmpty();
    }
}

package com.novelcraft.writer;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import com.example.liquidglass.LiquidGlassButton;
import android.widget.TextView;
import android.widget.Toast;

public class ChapterContentActivity extends android.app.Activity {

    private MediaPlayer mClickPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter_content);
        ThemeManager.apply(this);

        TextView tvTitle = findViewById(R.id.tvTitle);
        TextView tvContent = findViewById(R.id.tvContent);
        LiquidGlassButton btnCopy = findViewById(R.id.btnCopy);
        LiquidGlassButton btnBack = findViewById(R.id.btnBack);
        LiquidGlassButton btnExport = findViewById(R.id.btnExport);

        String title = getIntent().getStringExtra("title");
        String content = getIntent().getStringExtra("content");
        if (title == null) title = "";
        if (content == null) content = "";
        final String chapterTitle = title;
        final String chapterBody = content;

        tvTitle.setText(chapterTitle);
        tvContent.setText(chapterBody.isEmpty() ? getString(R.string.chapter_empty) : chapterBody);

        btnBack.setOnClickListener(v -> { playClickSound(); finish(); });

        btnExport.setOnClickListener(v -> {
            playClickSound();
            if (chapterBody.isEmpty()) {
                Toast.makeText(this, R.string.share_empty, Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                String where = SaveHelper.saveNovel(this, chapterTitle, chapterBody);
                Toast.makeText(this, getString(R.string.export_toast, where), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.saved_error, e.getMessage()), Toast.LENGTH_LONG).show();
            }
        });

        btnCopy.setOnClickListener(v -> {
            playClickSound();
            if (chapterBody.isEmpty()) {
                Toast.makeText(this, R.string.share_empty, Toast.LENGTH_SHORT).show();
                return;
            }
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("chapter", chapterTitle + "\n\n" + chapterBody));
            Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show();
        });
    }

    private void playClickSound() {
        try {
            if (mClickPlayer != null) {
                mClickPlayer.release();
                mClickPlayer = null;
            }
            mClickPlayer = MediaPlayer.create(this, R.raw.click_sound);
            if (mClickPlayer != null) {
                mClickPlayer.setOnCompletionListener(m -> {
                    m.release();
                    mClickPlayer = null;
                });
                mClickPlayer.start();
            }
        } catch (Exception ignored) {
        }
    }
}

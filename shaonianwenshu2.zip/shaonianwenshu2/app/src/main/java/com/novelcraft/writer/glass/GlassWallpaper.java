package com.novelcraft.writer.glass;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.DisplayMetrics;
import android.view.View;

import com.novelcraft.writer.ThemeManager;

/**
 * 液态玻璃的“壁纸”底。
 *
 * 窗口背景与所有液态玻璃控件共用同一张离屏位图：
 * 窗口负责把这张图铺在最底层，玻璃控件则通过 BitmapShader 采样它并做折射，
 * 从而产生真实的“透过玻璃看到背景并发生扭曲”的液态玻璃观感。
 */
public final class GlassWallpaper {

    public static final class Wallpaper {
        public final Bitmap sharp;    // 全分辨率：用于 API 33+ 的折射采样
        public final Bitmap blurred;  // 缩小图：低版本作为磨砂底
        public final int width;
        public final int height;

        Wallpaper(Bitmap sharp, Bitmap blurred, int width, int height) {
            this.sharp = sharp;
            this.blurred = blurred;
            this.width = width;
            this.height = height;
        }
    }

    private static Wallpaper current;
    private static String currentKey;

    private GlassWallpaper() {
    }

    public static synchronized Wallpaper get(Context context, View anyView) {
        if (context == null) return null;
        // 始终按屏幕尺寸生成，保证 Activity / Popup / Dialog 共用同一张底图与同一套屏幕坐标
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        return get(context, dm.widthPixels, dm.heightPixels);
    }

    public static synchronized Wallpaper get(Context context, int w, int h) {
        if (context == null || w <= 0 || h <= 0) return null;
        String key = w + "x" + h + "|" + ThemeManager.getMode(context)
                + "|" + ThemeManager.getBg(context) + "|" + ThemeManager.getText(context);
        Wallpaper cached = current;
        if (cached != null && key.equals(currentKey)
                && cached.width == w && cached.height == h) {
            return cached;
        }
        Wallpaper wp = render(context, w, h);
        current = wp;
        currentKey = key;
        return wp;
    }

    private static Wallpaper render(Context context, int w, int h) {
        // 纯黑 / 纯白：用户要求背景只用黑白两色，不再使用彩色渐变底
        boolean light = ThemeManager.MODE_LIGHT.equals(ThemeManager.getMode(context));
        int color;
        if (light) {
            color = 0xFFFFFFFF;
        } else if (ThemeManager.MODE_CUSTOM.equals(ThemeManager.getMode(context))) {
            color = 0xFF000000 | (ThemeManager.getBg(context) & 0xFFFFFF);
        } else {
            color = 0xFF000000;
        }
        int bw = Math.min(w, 4);
        int bh = Math.min(h, 4);
        Bitmap sharp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        sharp.eraseColor(color);
        return new Wallpaper(sharp, sharp, w, h);
    }

    private static Shader radial(float cx, float cy, float r, int inner, int outer) {
        return new RadialGradient(cx, cy, Math.max(1f, r),
                new int[]{inner, outer, 0x00000000},
                new float[]{0f, 0.5f, 1f},
                Shader.TileMode.CLAMP);
    }

    /** 主题变化时丢弃缓存。 */
    public static synchronized void invalidate() {
        current = null;
        currentKey = null;
    }
}

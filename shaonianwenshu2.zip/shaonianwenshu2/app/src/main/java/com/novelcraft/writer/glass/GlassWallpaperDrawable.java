package com.novelcraft.writer.glass;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.View;

import com.novelcraft.writer.App;

/**
 * 窗口背景：铺满液态玻璃底图（{@link GlassWallpaper}）。
 * 所有页面的根布局背景都会透明化，让这张底图透出来，玻璃控件才有可折射的内容。
 *
 * 注意：XML 实例化自定义 Drawable 走的是无参构造 + inflate()，Context 在这里惰性获取。
 */
public class GlassWallpaperDrawable extends Drawable {

    private Context context;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

    public GlassWallpaperDrawable() {
    }

    public GlassWallpaperDrawable(Context context) {
        this.context = context == null ? null : context.getApplicationContext();
    }

    public GlassWallpaperDrawable(Context context, android.util.AttributeSet attrs) {
        this(context);
    }

    private Context resolveContext() {
        if (context != null) return context;
        if (getCallback() instanceof View) {
            Context c = ((View) getCallback()).getContext();
            if (c != null) return c;
        }
        return App.ctx();
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        Context ctx = resolveContext();
        GlassWallpaper.Wallpaper wp = ctx == null ? null : GlassWallpaper.get(ctx, (View) null);
        if (wp == null || wp.sharp == null) {
            canvas.drawColor(0xFF0B0E13);
            return;
        }
        canvas.drawBitmap(wp.sharp, null, b, paint);
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.OPAQUE;
    }
}

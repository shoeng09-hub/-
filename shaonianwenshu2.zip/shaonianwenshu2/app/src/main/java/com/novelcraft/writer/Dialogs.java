package com.novelcraft.writer;

import android.app.Activity;
import android.app.AlertDialog;

/** 公共对话框：帮助 FAQ。 */
public class Dialogs {

    public static void showHelp(final Activity activity) {
        new AlertDialog.Builder(activity)
                .setTitle(R.string.help_title)
                .setMessage(R.string.help_faq)
                .setPositiveButton(R.string.btn_ok, null)
                .show();
    }
}

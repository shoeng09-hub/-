package com.novelcraft.writer;

import android.app.Activity;
import android.content.Intent;

import com.example.liquidglass.LiquidGlassTabBar;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

/** 底部 Dock（LiquidGlassTabBar）统一接线：0=首页 1=书库 2=创作 3=设置。 */
public final class GlassNav {

    public interface Handler {
        void onTab(int index);
    }

    private GlassNav() {
    }

    public static void setup(final Activity activity, int selected, final Handler handler) {
        LiquidGlassTabBar bar = activity.findViewById(R.id.bottomNavBar);
        if (bar == null) return;
        bar.setSelectedIndex(selected);
        bar.setOnTabSelected(new Function1<Integer, Unit>() {
            @Override
            public Unit invoke(Integer index) {
                if (handler != null && index != null) {
                    handler.onTab(index);
                }
                return Unit.INSTANCE;
            }
        });
    }

    /** 每次页面可见后调用，把底部 Dock 高亮矫正到当前页对应的索引，避免跨页返回后定位错乱。 */
    public static void correct(Activity activity) {
        LiquidGlassTabBar bar = activity.findViewById(R.id.bottomNavBar);
        if (bar == null) return;
        int index;
        if (activity instanceof MainActivity) {
            index = 0;
        } else if (activity instanceof LibraryActivity) {
            index = 1;
        } else if (activity instanceof SettingsActivity) {
            index = 3;
        } else {
            return;
        }
        bar.setSelectedIndex(index);
    }

    /** 默认跨页跳转：首页回 Main，书库开 Library，创作开创作设置，设置开 Settings；当前页跳过。 */
    public static void navigate(Activity activity, int index) {
        Class<?> current = activity.getClass();
        if (index == 0) {
            if (current != MainActivity.class) {
                Intent it = new Intent(activity, MainActivity.class);
                it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                activity.startActivity(it);
            }
        } else if (index == 2) {
            if (current != CreationSettingsActivity.class) {
                activity.startActivity(new Intent(activity, CreationSettingsActivity.class));
            }
        } else if (index == 1) {
            if (current != LibraryActivity.class) {
                activity.startActivity(new Intent(activity, LibraryActivity.class));
            }
        } else if (index == 3) {
            if (current != SettingsActivity.class) {
                activity.startActivity(new Intent(activity, SettingsActivity.class));
            }
        }
    }
}

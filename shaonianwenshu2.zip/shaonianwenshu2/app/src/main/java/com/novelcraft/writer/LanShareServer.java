package com.novelcraft.writer;

import android.graphics.Bitmap;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.EnumMap;
import java.util.Map;

/** 局域网分享：内置 HTTP 服务器把小说正文提供给同一 Wi-Fi 下的另一台设备。 */
public final class LanShareServer {

    public static final String SHARE_SCHEME = "shaonianwenshu";

    private ServerSocket serverSocket;
    private Thread acceptThread;
    private volatile boolean running = false;
    private String url = "";
    private String deepLink = "";

    public synchronized void start(String title, String content) throws Exception {
        stop();
        String safeTitle = title == null ? "小说" : title;
        String body = content == null ? "" : content;

        String ip = localIpv4();
        if (ip == null) {
            throw new IllegalStateException("未连接到局域网");
        }

        ServerSocket ss = null;
        int port = 0;
        for (int p = 8756; p <= 8780; p++) {
            try {
                ServerSocket candidate = new ServerSocket();
                candidate.setReuseAddress(true);
                candidate.bind(new InetSocketAddress(p));
                ss = candidate;
                port = p;
                break;
            } catch (Exception ignored) {
            }
        }
        if (ss == null) {
            throw new IllegalStateException("局域网端口被占用");
        }

        serverSocket = ss;
        running = true;
        url = "http://" + ip + ":" + port + "/";
        String fileUrl = url + "novel.txt";
        deepLink = SHARE_SCHEME + "://import?t=" + encode(safeTitle) + "&u=" + encode(fileUrl);

        final String fTitle = safeTitle;
        final String fBody = body;
        acceptThread = new Thread(() -> acceptLoop(fTitle, fBody), "lan-share-accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
    }

    public String getUrl() {
        return url;
    }

    public String getDeepLink() {
        return deepLink;
    }

    public synchronized void stop() {
        running = false;
        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (Exception ignored) {
            }
            serverSocket = null;
        }
        acceptThread = null;
    }

    private static String encode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private void acceptLoop(String title, String content) {
        while (running) {
            try (Socket socket = serverSocket.accept()) {
                handle(socket, title, content);
            } catch (Exception ignored) {
                if (!running) {
                    break;
                }
            }
        }
    }

    private void handle(Socket socket, String title, String content) {
        try {
            InputStream in = socket.getInputStream();
            ByteArrayOutputStream headBuf = new ByteArrayOutputStream();
            int prev = -1;
            int cur;
            while ((cur = in.read()) != -1) {
                headBuf.write(cur);
                byte[] b = headBuf.toByteArray();
                int n = b.length;
                if (n >= 4 && b[n - 4] == '\r' && b[n - 3] == '\n' && b[n - 2] == '\r' && b[n - 1] == '\n') {
                    break;
                }
                prev = cur;
                if (headBuf.size() > 16384) {
                    break;
                }
            }
            String head = headBuf.toString("UTF-8");
            String firstLine = head;
            int nl = head.indexOf("\r\n");
            if (nl > 0) {
                firstLine = head.substring(0, nl);
            }
            String path = "/";
            String[] parts = firstLine.split(" ");
            if (parts.length >= 2) {
                path = parts[1];
            }

            OutputStream out = new BufferedOutputStream(socket.getOutputStream());
            if (path.startsWith("/novel.txt")) {
                byte[] body = content.getBytes(StandardCharsets.UTF_8);
                String fileName = "少年文枢分享_" + (title == null || title.isEmpty() ? "小说" : title) + ".txt";
                String header = "HTTP/1.1 200 OK\r\n"
                        + "Content-Type: text/plain; charset=utf-8\r\n"
                        + "Content-Disposition: attachment; filename*=UTF-8''" + encode(fileName) + "\r\n"
                        + "Content-Length: " + body.length + "\r\n"
                        + "Connection: close\r\n\r\n";
                out.write(header.getBytes(StandardCharsets.UTF_8));
                out.write(body);
            } else {
                byte[] body = buildPage(title).getBytes(StandardCharsets.UTF_8);
                String header = "HTTP/1.1 200 OK\r\n"
                        + "Content-Type: text/html; charset=utf-8\r\n"
                        + "Content-Length: " + body.length + "\r\n"
                        + "Connection: close\r\n\r\n";
                out.write(header.getBytes(StandardCharsets.UTF_8));
                out.write(body);
            }
            out.flush();
        } catch (Exception ignored) {
        }
    }

    private String buildPage(String title) {
        String t = htmlEscape(title == null ? "" : title);
        return "<!doctype html><html><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>少年文枢 · 局域网分享</title></head>"
                + "<body style=\"margin:0;background:#121212;color:#F5F5F5;font-family:sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center\">"
                + "<div style=\"text-align:center;padding:24px\">"
                + "<h2 style=\"color:#C9A961;margin:0 0 12px\">《" + t + "》</h2>"
                + "<p style=\"color:#B0B0B0\">点击下载 TXT，或扫描分享二维码导入《少年文枢》书库</p>"
                + "<p><a href=\"/novel.txt\" style=\"display:inline-block;padding:14px 28px;border-radius:999px;background:#C9A961;color:#121212;font-weight:bold;text-decoration:none\">下载小说 TXT</a></p>"
                + "</div></body></html>";
    }

    private static String htmlEscape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    /** 生成二维码位图；失败返回 null。 */
    public static Bitmap makeQr(String text, int size) {
        try {
            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.MARGIN, 1);
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
            BitMatrix matrix = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints);
            int[] pixels = new int[size * size];
            for (int y = 0; y < size; y++) {
                int offset = y * size;
                for (int x = 0; x < size; x++) {
                    pixels[offset + x] = matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
                }
            }
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            bmp.setPixels(pixels, 0, size, 0, 0, size, size);
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    private static String localIpv4() {
        try {
            Enumeration<NetworkInterface> ifs = NetworkInterface.getNetworkInterfaces();
            String fallback = null;
            while (ifs != null && ifs.hasMoreElements()) {
                NetworkInterface nif = ifs.nextElement();
                if (!nif.isUp() || nif.isLoopback()) {
                    continue;
                }
                String name = nif.getName();
                if (name != null && name.startsWith("rmnet")) {
                    continue;
                }
                Enumeration<InetAddress> addrs = nif.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        if (a.isSiteLocalAddress()) {
                            return a.getHostAddress();
                        }
                        if (fallback == null) {
                            fallback = a.getHostAddress();
                        }
                    }
                }
            }
            return fallback;
        } catch (Exception e) {
            return null;
        }
    }
}

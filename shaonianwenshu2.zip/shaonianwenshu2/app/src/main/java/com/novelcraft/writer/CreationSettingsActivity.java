package com.novelcraft.writer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.List;
import com.example.liquidglass.LiquidGlassButton;
import com.example.liquidglass.LiquidGlassChip;
import com.novelcraft.writer.NovelService.NovelCallback;

public class CreationSettingsActivity extends android.app.Activity {

    private EditText etTitle, etHeroName, etMainContent, etContextSummary,
            etStyle, etTotalChapters, etChapterTitle;
    private LiquidGlassChip cbUseSummary;
    private Spinner spinnerGenre;
    private com.example.liquidglass.LiquidGlassSlider sliderChapterLen;
    private LiquidGlassButton btnGenSummary, btnSaveSettings;

    private NovelService service;
    private SharedPreferences editorPrefs;

    private static final int REQUEST_GEN_SUMMARY = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creation_settings);
        ThemeManager.apply(this);

        service = new NovelService(this);
        editorPrefs = getSharedPreferences("editor_prefs", MODE_PRIVATE);

        bindViews();
        setupSpinners();
        restoreSettings();
        setupActions();
    }

    private void bindViews() {
        etTitle = findViewById(R.id.etTitle);
        etHeroName = findViewById(R.id.etHeroName);
        etMainContent = findViewById(R.id.etMainContent);
        etContextSummary = findViewById(R.id.etContextSummary);
        cbUseSummary = findViewById(R.id.cbUseSummary);
        spinnerGenre = findViewById(R.id.spinnerGenre);
        etStyle = findViewById(R.id.etStyle);
        sliderChapterLen = findViewById(R.id.sliderChapterLen);
        etTotalChapters = findViewById(R.id.etTotalChapters);
        etChapterTitle = findViewById(R.id.etChapterTitle);
        btnGenSummary = findViewById(R.id.btnGenSummary);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);
    }

    private void setupSpinners() {
        spinnerGenre.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                split(getString(R.string.genres))));
    }

    private void restoreSettings() {
        etTitle.setText(editorPrefs.getString("novel_title", ""));
        etHeroName.setText(editorPrefs.getString("heroName", ""));
        etMainContent.setText(editorPrefs.getString("mainContent", ""));
        etContextSummary.setText(editorPrefs.getString("contextSummary", ""));
        cbUseSummary.setChecked(editorPrefs.getBoolean("useSummary", false));
        selectSpinnerValue(spinnerGenre, editorPrefs.getString("genre", ""));
        etStyle.setText(editorPrefs.getString("style", ""));
        int len = editorPrefs.getInt("chapterLength", -1);
        if (len > 0) sliderChapterLen.setValue(len);
        int tot = editorPrefs.getInt("totalChapters", 0);
        if (tot > 0) etTotalChapters.setText(String.valueOf(tot));
        etChapterTitle.setText(editorPrefs.getString("chapterTitle", ""));
    }

    private void saveSettings() {
        SharedPreferences.Editor edit = editorPrefs.edit();
        edit.putString("novel_title", etTitle.getText().toString().trim());
        edit.putString("heroName", etHeroName.getText().toString().trim());
        edit.putString("mainContent", etMainContent.getText().toString().trim());
        edit.putString("contextSummary", etContextSummary.getText().toString().trim());
        edit.putBoolean("useSummary", cbUseSummary.isChecked());
        edit.putString("genre", selectedGenre());
        edit.putString("style", etStyle.getText().toString().trim());
        edit.putInt("chapterLength", readChapterLength());
        edit.putInt("totalChapters", readTotalChapters());
        edit.putString("chapterTitle", etChapterTitle.getText().toString().trim());
        edit.apply();
    }

    private String selectedGenre() {
        Object g = spinnerGenre.getSelectedItem();
        return g == null ? "" : g.toString();
    }

    private int readChapterLength() {
        return sliderChapterLen.getValue();
    }

    private int readTotalChapters() {
        try {
            int v = Integer.parseInt(etTotalChapters.getText().toString().trim());
            return Math.max(0, v);
        } catch (Exception e) {
            return 0;
        }
    }

    private void selectSpinnerValue(Spinner spinner, String value) {
        if (value == null) return;
        for (int i = 0; i < spinner.getAdapter().getCount(); i++) {
            if (value.equals(spinner.getAdapter().getItem(i))) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private void setupActions() {
        btnGenSummary.setOnClickListener(v -> generateSummary());
        btnSaveSettings.setOnClickListener(v -> {
            saveSettings();
            Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        });

        View home = findViewById(android.R.id.home);
        if (home != null) home.setOnClickListener(v -> finish());
    }

    private void generateSummary() {
        String content = etMainContent.getText().toString().trim();
        if (content.isEmpty()) {
            Toast.makeText(this, R.string.summary_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!service.hasValidApiKey()) {
            Toast.makeText(this, R.string.error_api_key, Toast.LENGTH_SHORT).show();
            return;
        }
        service.summarize(content, new NovelCallback() {
            @Override
            public void onStatus(String status) {
            }

            @Override
            public void onContent(String fullText, boolean done) {
                if (done) {
                    etContextSummary.setText(fullText);
                    cbUseSummary.setChecked(true);
                    Toast.makeText(CreationSettingsActivity.this, R.string.summary_done, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(String error) {
                Toast.makeText(CreationSettingsActivity.this, error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private List<String> split(String src) {
        List<String> list = new java.util.ArrayList<>();
        if (src != null) {
            for (String s : src.split("\\|")) {
                if (!s.isEmpty()) list.add(s);
            }
        }
        return list;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (service != null) service.shutdown();
    }
}

package com.novelcraft.writer.glass;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewTreeObserver;

import com.novelcraft.writer.App;
import com.novelcraft.writer.R;
import com.novelcraft.writer.ThemeManager;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

/**
 * 液态玻璃 Drawable —— 把 Kyant 的 Backdrop (AndroidLiquidGlass) 核心效果移植到 View 体系。
 *
 * 原理：
 *  1. 通过 BitmapShader 采样 {@link GlassWallpaper} 的窗口级底图；
 *  2. API 33+ 使用 AGSL RuntimeShader 做圆角矩形边缘折射 + 色散（真实“液态玻璃”透镜变形）；
 *  3. 低版本退化为磨砂采样 + 高光描边；
 *  4. 叠加玻璃底色、顶部光泽、方向高光与 1dp 亮边。
 *
 * 可作为任意 View 的 android:background 在 XML 中直接使用。
 */
public class LiquidGlassDrawable extends android.graphics.drawable.Drawable {

    // ---------------------------------------------------------------------
    // AGSL shaders (ported from com.kyant.backdrop.internal.Shaders.kt)
    // ---------------------------------------------------------------------

    private static final String SDF_COMMON = "\n" +
            "float radiusAt(float2 coord, float4 radii) {\n" +
            "    if (coord.x >= 0.0) {\n" +
            "        if (coord.y <= 0.0) return radii.y;\n" +
            "        else return radii.z;\n" +
            "    } else {\n" +
            "        if (coord.y <= 0.0) return radii.x;\n" +
            "        else return radii.w;\n" +
            "    }\n" +
            "}\n" +
            "float sdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
            "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
            "    float outside = length(max(cornerCoord, 0.0)) - radius;\n" +
            "    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n" +
            "    return outside + inside;\n" +
            "}\n" +
            "float2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {\n" +
            "    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));\n" +
            "    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n" +
            "        float2 d = max(cornerCoord, 0.0);\n" +
            "        float l = length(d);\n" +
            "        return sign(coord) * (l > 0.0001 ? d / l : float2(0.0, 0.0));\n" +
            "    } else {\n" +
            "        float gradX = step(cornerCoord.y, cornerCoord.x);\n" +
            "        return sign(coord) * float2(gradX, 1.0 - gradX);\n" +
            "    }\n" +
            "}\n" +
            "float2 safeNormalize(float2 v) {\n" +
            "    float l = length(v);\n" +
            "    return l > 0.0001 ? v / l : float2(0.0, 0.0);\n" +
            "}\n" +
            "float circleMap(float x) {\n" +
            "    return 1.0 - sqrt(max(0.0, 1.0 - x * x));\n" +
            "}\n";

    private static final String REFRACTION_SHADER_STRING =
            "uniform shader content;\n" +
            "uniform float2 size;\n" +
            "uniform float4 cornerRadii;\n" +
            "uniform float refractionHeight;\n" +
            "uniform float refractionAmount;\n" +
            "uniform float depthEffect;\n" +
            "uniform float chromaticAberration;\n" +
            SDF_COMMON +
            "half4 main(float2 coord) {\n" +
            "    float2 halfSize = size * 0.5;\n" +
            "    float2 centeredCoord = coord - halfSize;\n" +
            "    float radius = radiusAt(centeredCoord, cornerRadii);\n" +
            "    float sd = sdRoundedRect(centeredCoord, halfSize, radius);\n" +
            "    if (-sd >= refractionHeight) {\n" +
            "        return content.eval(coord);\n" +
            "    }\n" +
            "    sd = min(sd, 0.0);\n" +
            "    float d = circleMap(1.0 - (-sd) / refractionHeight) * refractionAmount;\n" +
            "    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n" +
            "    float2 grad = safeNormalize(gradSdRoundedRect(centeredCoord, halfSize, gradRadius)\n" +
            "            + depthEffect * safeNormalize(centeredCoord));\n" +
            "    float2 refractedCoord = coord + d * grad;\n" +
            "    if (chromaticAberration > 0.5) {\n" +
            "        float dispersion = chromaticAberration\n" +
            "                * ((centeredCoord.x * centeredCoord.y) / max(1.0, halfSize.x * halfSize.y));\n" +
            "        float2 dispersedCoord = d * grad * dispersion;\n" +
            "        half4 color = half4(0.0);\n" +
            "        half4 red = content.eval(refractedCoord + dispersedCoord);\n" +
            "        color.r += red.r / 3.5; color.a += red.a / 7.0;\n" +
            "        half4 orange = content.eval(refractedCoord + dispersedCoord * (2.0 / 3.0));\n" +
            "        color.r += orange.r / 3.5; color.g += orange.g / 7.0; color.a += orange.a / 7.0;\n" +
            "        half4 yellow = content.eval(refractedCoord + dispersedCoord * (1.0 / 3.0));\n" +
            "        color.r += yellow.r / 3.5; color.g += yellow.g / 3.5; color.a += yellow.a / 7.0;\n" +
            "        half4 green = content.eval(refractedCoord);\n" +
            "        color.g += green.g / 3.5; color.a += green.a / 7.0;\n" +
            "        half4 cyan = content.eval(refractedCoord - dispersedCoord * (1.0 / 3.0));\n" +
            "        color.g += cyan.g / 3.5; color.b += cyan.b / 3.0; color.a += cyan.a / 7.0;\n" +
            "        half4 blue = content.eval(refractedCoord - dispersedCoord * (2.0 / 3.0));\n" +
            "        color.b += blue.b / 3.0; color.a += blue.a / 7.0;\n" +
            "        half4 purple = content.eval(refractedCoord - dispersedCoord);\n" +
            "        color.r += purple.r / 7.0; color.b += purple.b / 3.0; color.a += purple.a / 7.0;\n" +
            "        return color;\n" +
            "    }\n" +
            "    return content.eval(refractedCoord);\n" +
            "}\n";

    private static final String HIGHLIGHT_SHADER_STRING =
            "uniform float2 size;\n" +
            "uniform float4 cornerRadii;\n" +
            "layout(color) uniform half4 color;\n" +
            "uniform float angle;\n" +
            "uniform float falloff;\n" +
            SDF_COMMON +
            "half4 main(float2 coord) {\n" +
            "    float2 halfSize = size * 0.5;\n" +
            "    float2 centeredCoord = coord - halfSize;\n" +
            "    float radius = radiusAt(centeredCoord, cornerRadii);\n" +
            "    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n" +
            "    float2 grad = gradSdRoundedRect(centeredCoord, halfSize, gradRadius);\n" +
            "    float2 normal = float2(cos(angle), sin(angle));\n" +
            "    float d = dot(grad, normal);\n" +
            "    float intensity = pow(abs(d), falloff);\n" +
            "    return color * intensity;\n" +
            "}\n";

    // ---------------------------------------------------------------------
    // Config
    // ---------------------------------------------------------------------

    private Context context;
    private float radius;
    private float refractionHeight;
    private float refractionAmount;
    private float highlightAlpha;
    private float sheenAlpha;
    private boolean chromatic;
    private int fixedTint;
    private int fixedStroke;
    private float strokeWidth;
    private float paddingPx;
    private boolean forceFallback;

    private float alpha = 1f;

    // ---------------------------------------------------------------------
    // Paints & shader cache
    // ---------------------------------------------------------------------

    private final Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheenPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint highlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private RuntimeShader refractionShader;
    private RuntimeShader highlightShader;
    private boolean shaderBroken;

    private BitmapShader contentShader;
    private Bitmap contentBitmap;

    private final Matrix matrix = new Matrix();
    private final int[] viewLoc = new int[2];

    private View listenerView;
    private boolean isPressed;

    private final ViewTreeObserver.OnScrollChangedListener scrollListener = new ViewTreeObserver.OnScrollChangedListener() {
        @Override
        public void onScrollChanged() {
            invalidateSelf();
        }
    };

    // ---------------------------------------------------------------------
    // Constructors
    // ---------------------------------------------------------------------

    public LiquidGlassDrawable() {
        initDefaults(Resources.getSystem().getDisplayMetrics());
    }

    public LiquidGlassDrawable(Context context) {
        this(context, 20);
    }

    public LiquidGlassDrawable(Context context, float radiusDp) {
        this.context = context == null ? null : context.getApplicationContext();
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        initDefaults(dm);
        radius = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, radiusDp, dm);
    }

    public LiquidGlassDrawable(Context context, AttributeSet attrs) {
        this(context);
        if (attrs == null) return;
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.LiquidGlassDrawable);
        try {
            parseAttrs(a);
        } finally {
            a.recycle();
        }
    }

    private void initDefaults(DisplayMetrics dm) {
        radius = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, dm);
        refractionHeight = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 18, dm);
        refractionAmount = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 14, dm);
        highlightAlpha = 0.55f;
        sheenAlpha = 0.10f;
        chromatic = true;
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, dm);
    }

    private void parseAttrs(TypedArray a) {
        float r = a.getDimension(R.styleable.LiquidGlassDrawable_glassRadius, -1);
        if (r >= 0) radius = r;
        float rh = a.getDimension(R.styleable.LiquidGlassDrawable_glassRefractionHeight, -1);
        if (rh >= 0) refractionHeight = rh;
        float ra = a.getDimension(R.styleable.LiquidGlassDrawable_glassRefractionAmount, -1);
        if (ra >= 0) refractionAmount = ra;
        highlightAlpha = a.getFloat(R.styleable.LiquidGlassDrawable_glassHighlight, highlightAlpha);
        sheenAlpha = a.getFloat(R.styleable.LiquidGlassDrawable_glassSheen, sheenAlpha);
        chromatic = a.getBoolean(R.styleable.LiquidGlassDrawable_glassChromatic, chromatic);
        strokeWidth = a.getDimension(R.styleable.LiquidGlassDrawable_glassStrokeWidth, strokeWidth);
        fixedTint = a.getColor(R.styleable.LiquidGlassDrawable_glassTint, 0);
        fixedStroke = a.getColor(R.styleable.LiquidGlassDrawable_glassStrokeColor, 0);
        paddingPx = a.getDimension(R.styleable.LiquidGlassDrawable_glassPadding, paddingPx);
        float ta = a.getFloat(R.styleable.LiquidGlassDrawable_glassTintAlpha, -1f);
        if (ta >= 0f) tintAlphaOverride = ta;
    }

    /**
     * 关键兼容点：框架从 XML 实例化自定义 Drawable 时只调用无参构造函数，
     * 属性通过 inflate() 传入（Android 各版本皆如此）。
     */
    @Override
    public void inflate(Resources r, XmlPullParser parser, AttributeSet attrs, Resources.Theme theme)
            throws XmlPullParserException, IOException {
        super.inflate(r, parser, attrs, theme);
        if (attrs == null) return;
        TypedArray a = r.obtainAttributes(attrs, R.styleable.LiquidGlassDrawable);
        try {
            parseAttrs(a);
        } finally {
            a.recycle();
        }
    }

    /** 取 Context：XML 实例化时可能没有，逐级回退到被设置背景的 View / 全局 Application。 */
    private Context resolveContext() {
        if (context != null) return context;
        if (getCallback() instanceof View) {
            Context c = ((View) getCallback()).getContext();
            if (c != null) return c;
        }
        return App.ctx();
    }

    private float tintAlphaOverride = -1f;

    // ---------------------------------------------------------------------
    // Public tuning API
    // ---------------------------------------------------------------------

    public void setGlassRadius(float r) {
        radius = r;
        invalidateSelf();
    }

    public void setRefraction(float height, float amount) {
        refractionHeight = height;
        refractionAmount = amount;
        invalidateSelf();
    }

    public void setTintOverride(int color) {
        fixedTint = color;
        invalidateSelf();
    }

    public void setHighlightAlpha(float v) {
        highlightAlpha = v;
        invalidateSelf();
    }

    public void setGlassPadding(float px) {
        paddingPx = px;
        invalidateSelf();
    }

    // ---------------------------------------------------------------------
    // Drawable
    // ---------------------------------------------------------------------

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        int w = b.width();
        int h = b.height();
        if (w <= 0 || h <= 0) return;
        float r = Math.min(radius, Math.min(w, h) / 2f);

        int save = canvas.save();
        canvas.translate(b.left, b.top);

        View v = getCallback() instanceof View ? (View) getCallback() : null;
        if (!forceFallback && v != null && !v.isInEditMode()
                && v.isAttachedToWindow() && v.getRootView() != null) {
            attachScrollListener(v);
            drawBackdrop(canvas, v, w, h, r);
        }

        int tint = resolveTint();
        tintPaint.setColor(tint);
        tintPaint.setAlpha(Math.round(Color.alpha(tint) * alpha));

        canvas.drawRoundRect(0, 0, w, h, r, r, tintPaint);

        // 顶部光泽
        if (sheenAlpha > 0f) {
            sheenPaint.setShader(new LinearGradient(0, 0, w * 0.35f, h,
                    new int[]{(Math.round(255 * sheenAlpha * alpha) << 24) | 0xFFFFFF,
                            (Math.round(90 * sheenAlpha * alpha) << 24) | 0xFFFFFF,
                            0x00FFFFFF},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRoundRect(0, 0, w, h, r, r, sheenPaint);
            sheenPaint.setShader(null);
        }

        // 方向高光（玻璃质感的关键）
        if (highlightAlpha > 0f) {
            if (drawHighlightShader(canvas, w, h, r)) {
                // handled by shader
            } else {
                highlightPaint.setShader(new LinearGradient(0, 0, w, h,
                        new int[]{(Math.round(150 * highlightAlpha * alpha) << 24) | 0xFFFFFF,
                                0x14FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.35f, 0.75f}, Shader.TileMode.CLAMP));
                canvas.drawRoundRect(0, 0, w, h, r, r, highlightPaint);
                highlightPaint.setShader(null);
            }
        }

        // 亮边
        if (strokeWidth > 0f) {
            int sc = fixedStroke != 0 ? fixedStroke : resolveStroke();
            int sa = Math.round(Color.alpha(sc) * alpha);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(strokeWidth);
            strokePaint.setColor((sa << 24) | (sc & 0xFFFFFF));
            canvas.drawRoundRect(strokeWidth / 2f, strokeWidth / 2f,
                    w - strokeWidth / 2f, h - strokeWidth / 2f, r, r, strokePaint);
        }

        canvas.restoreToCount(save);
    }

    private boolean drawBackdrop(Canvas canvas, View v, int w, int h, float r) {
        Context ctx = resolveContext();
        if (ctx == null) return false;
        GlassWallpaper.Wallpaper wp = GlassWallpaper.get(ctx, v);
        if (wp == null) return false;

        int[] vl = viewLoc;
        v.getLocationOnScreen(vl);
        // 底图按屏幕坐标生成：窗口背景、弹窗、对话框都在同一张底图上采样
        float ox = vl[0];
        float oy = vl[1];

        boolean useShader = Build.VERSION.SDK_INT >= 33 && !shaderBroken;
        Bitmap bmp = useShader ? wp.sharp : wp.blurred;
        if (bmp == null || bmp.isRecycled()) {
            bmp = wp.blurred != null ? wp.blurred : wp.sharp;
            useShader = false;
        }
        if (bmp == null) return false;

        if (contentShader == null || contentBitmap != bmp) {
            contentShader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            contentBitmap = bmp;
        }
        // 纯色底：小图直接 1:1 采样（CLAMP 后整片同色）
        float scale = (wp.blurred != null && bmp == wp.blurred && bmp.getWidth() > 8) ? 6f : 1f;
        matrix.reset();
        matrix.setTranslate(ox, oy);
        if (scale != 1f) matrix.postScale(1f / scale, 1f / scale);
        contentShader.setLocalMatrix(matrix);

        if (useShader) {
            if (refractionShader == null) {
                try {
                    refractionShader = new RuntimeShader(REFRACTION_SHADER_STRING);
                } catch (Throwable t) {
                    shaderBroken = true;
                    refractionShader = null;
                    return false;
                }
            }
            float press = isPressed ? 1.35f : 1f;
            refractionShader.setInputShader("content", contentShader);
            refractionShader.setFloatUniform("size", (float) w, (float) h);
            refractionShader.setFloatUniform("cornerRadii", r, r, r, r);
            refractionShader.setFloatUniform("refractionHeight", refractionHeight);
            refractionShader.setFloatUniform("refractionAmount", -refractionAmount * press);
            refractionShader.setFloatUniform("depthEffect", 0f);
            refractionShader.setFloatUniform("chromaticAberration", chromatic ? 1f : 0f);
            glassPaint.setShader(refractionShader);
        } else {
            glassPaint.setShader(contentShader);
        }
        canvas.drawRoundRect(0, 0, w, h, r, r, glassPaint);

        // 稍微提亮玻璃内部（vibrancy 的近似）
        if (useShader) {
            glassPaint.setShader(null);
            tintPaint.setColor(0x14FFFFFF);
            tintPaint.setAlpha(Math.round(0x14 * alpha));
            canvas.drawRoundRect(0, 0, w, h, r, r, tintPaint);
        }
        glassPaint.setShader(null);
        return true;
    }

    private boolean drawHighlightShader(Canvas canvas, int w, int h, float r) {
        if (Build.VERSION.SDK_INT < 33 || shaderBroken) return false;
        if (highlightShader == null) {
            try {
                highlightShader = new RuntimeShader(HIGHLIGHT_SHADER_STRING);
            } catch (Throwable t) {
                shaderBroken = true;
                return false;
            }
        }
        try {
            Context ctx = resolveContext();
            boolean light = ctx != null && ThemeManager.MODE_LIGHT.equals(ThemeManager.getMode(ctx));
            float a = highlightAlpha * alpha * (isPressed ? 1.25f : 1f);
            highlightShader.setFloatUniform("size", (float) w, (float) h);
            highlightShader.setFloatUniform("cornerRadii", r, r, r, r);
            highlightShader.setColorUniform("color", Color.argb(255, 255, 255, 255));
            highlightShader.setFloatUniform("angle", light ? 2.356f : 0.785f);
            highlightShader.setFloatUniform("falloff", 1f);
            highlightPaint.setShader(highlightShader);
            highlightPaint.setAlpha(Math.round(Math.min(1f, a) * (light ? 200 : 255)));
            canvas.drawRoundRect(0, 0, w, h, r, r, highlightPaint);
            highlightPaint.setShader(null);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private int resolveTint() {
        if (fixedTint != 0) return fixedTint;
        Context ctx = resolveContext();
        boolean light = ctx != null && ThemeManager.MODE_LIGHT.equals(ThemeManager.getMode(ctx));
        if (tintAlphaOverride >= 0f) {
            int alpha255 = Math.round(Math.min(1f, tintAlphaOverride) * 255);
            return (alpha255 << 24) | (light ? 0xFFFFFF : 0x000000);
        }
        return light ? 0x7AFFFFFF : 0x8C000000;
    }

    private int resolveStroke() {
        Context ctx = resolveContext();
        boolean light = ctx != null && ThemeManager.MODE_LIGHT.equals(ThemeManager.getMode(ctx));
        return light ? 0x66FFFFFF : 0x38FFFFFF;
    }

    private void attachScrollListener(View v) {
        if (v == listenerView) return;
        if (listenerView != null) {
            ViewTreeObserver o = listenerView.getViewTreeObserver();
            if (o.isAlive()) o.removeOnScrollChangedListener(scrollListener);
        }
        listenerView = v;
        ViewTreeObserver o = v.getViewTreeObserver();
        if (o.isAlive()) o.addOnScrollChangedListener(scrollListener);
    }

    // ---------------------------------------------------------------------
    // Drawable plumbing
    // ---------------------------------------------------------------------

    @Override
    public void getOutline(Outline outline) {
        Rect b = getBounds();
        float r = Math.min(radius, Math.min(b.width(), b.height()) / 2f);
        outline.setRoundRect(b, r);
    }

    @Override
    public boolean getPadding(Rect padding) {
        int p = Math.round(paddingPx);
        if (p > 0) {
            padding.set(p, p, p, p);
            return true;
        }
        padding.set(0, 0, 0, 0);
        return false;
    }

    @Override
    public void setAlpha(int a) {
        alpha = a / 255f;
        invalidateSelf();
    }

    @Override
    public int getAlpha() {
        return Math.round(alpha * 255);
    }

    @Override
    public void setColorFilter(android.graphics.ColorFilter cf) {
        // 玻璃颜色由主题控制
    }

    @Override
    public int getOpacity() {
        return android.graphics.PixelFormat.TRANSLUCENT;
    }

    @Override
    public boolean isStateful() {
        return true;
    }

    @Override
    protected boolean onStateChange(int[] state) {
        boolean pressed = false;
        for (int s : state) {
            if (s == android.R.attr.state_pressed) {
                pressed = true;
                break;
            }
        }
        if (pressed != isPressed) {
            isPressed = pressed;
            invalidateSelf();
            return true;
        }
        return false;
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        contentShader = null;
        contentBitmap = null;
    }
}

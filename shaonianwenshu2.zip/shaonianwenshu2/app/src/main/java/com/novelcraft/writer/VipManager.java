package com.novelcraft.writer;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 临时 VIP 管理（本地）。
 * 说明：支付/服务端校验尚未接入，这里预留 {@link ServerVerifier} 接口，
 * 后续接入服务器后把 redeem/verify 改为调用服务端即可，其余调用方无需改动。
 */
public class VipManager {

    private static final String PREFS = "vip_prefs";
    private static final String KEY_EXPIRE = "vip_expire";
    private static final String KEY_SERVER = "vip_server";
    private static final String DEFAULT_SERVER = "http://39.96.78.250:18081";
    private static final String ALT_SERVER = "http://39.96.78.250";
    private static final String ANNO_HISTORY = "anno_history";
    private static final String WENSHU_ANNO_HISTORY = "wenshu_anno_history";
    private static final int MAX_ANNO_HISTORY = 30;

    // 免费用户单章字数上限
    public static final int FREE_MAX_CHAPTER_LENGTH = 3000;
    // 价格（仅展示）
    public static final String PRICE_MONTH = "15.9";
    public static final String PRICE_WEEK = "4.9";

    /** 预留：服务端校验接口。接入服务器后实现此接口。 */
    public interface ServerVerifier {
        boolean verify(String orderToken);
        void purchase(Context context, String planId, PurchaseCallback callback);
    }

    public interface PurchaseCallback {
        void onSuccess(long expireAtMillis);
        void onFail(String message);
    }

    private static ServerVerifier serverVerifier = null;

    public static void setServerVerifier(ServerVerifier v) {
        serverVerifier = v;
    }

    public static boolean isServerReady() {
        return serverVerifier != null;
    }

    public static boolean isVip(Context context) {
        // 公益竞赛版：默认解锁全部功能，无需 VIP。
        return true;
    }

    public static long expiry(Context context) {
        SharedPreferences p = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return p.getLong(KEY_EXPIRE, 0L);
    }

    public static String expiryText(Context context) {
        long e = expiry(context);
        if (e <= System.currentTimeMillis()) return "";
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(e));
    }

    public static void setVip(Context context, int days) {
        long base = Math.max(System.currentTimeMillis(), expiry(context));
        long expire = base + (long) days * 24L * 60L * 60L * 1000L;
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong(KEY_EXPIRE, expire).apply();
    }

    /** 用服务器返回的到期时间（毫秒）设置 VIP。 */
    public static void setVipExpireAt(Context context, long expireMs) {
        if (expireMs <= System.currentTimeMillis()) return;
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong(KEY_EXPIRE, expireMs).apply();
    }

    public static String getServer(Context context) {
        SharedPreferences p = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        // 一次性迁移：清除旧版本遗留的服务器地址（如 192.168.x.x），统一用最新默认地址
        if (!p.getBoolean("server_v2", false)) {
            p.edit().putString(KEY_SERVER, DEFAULT_SERVER).putBoolean("server_v2", true).apply();
        }
        return p.getString(KEY_SERVER, DEFAULT_SERVER);
    }

    public static void setServer(Context context, String url) {
        if (url == null) return;
        String u = url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_SERVER, u).apply();
    }

    public static void clearVip(Context context) {
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().remove(KEY_EXPIRE).apply();
    }

    /** 直接用系统浏览器打开 VIP 网页（带上本机设备ID，保证网页与 App 是同一设备）。 */
    public static void openVipPage(Context context) {
        try {
            String url = ALT_SERVER + "/?device_id=" + java.net.URLEncoder.encode(getDeviceId(context), "UTF-8");
            android.content.Intent it = new android.content.Intent(
                    android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
            it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(it);
        } catch (Exception ignored) {
        }
    }

    /** 本机设备ID：首次生成 UUID 并持久化，App 与网页共用同一个。 */
    public static String getDeviceId(Context context) {
        SharedPreferences p = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String d = p.getString("device_id", "");
        if (d == null || d.isEmpty()) {
            d = java.util.UUID.randomUUID().toString();
            p.edit().putString("device_id", d).apply();
        }
        return d;
    }

    public interface SyncCallback {
        /** connected=是否成功连上服务器；isVip=服务器判定的VIP；expireTime=服务器返回的到期日；message=一次性消息。 */
        void onSynced(boolean connected, boolean isVip, String expireTime, String message);
    }

    public interface AnnounceCallback {
        void onAnnouncement(String text, boolean isNew);
    }

    /** 拉取服务器公告；版本比本地新且非空时回调（每次只弹一次）。 */
    public static void checkAnnouncement(final Context context, final AnnounceCallback cb) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    org.json.JSONObject o = httpJson(context, "/api/announcement", null);
                    if (o != null && o.optBoolean("ok", false)) {
                        int ver = o.optInt("version", 0);
                        String text = o.optString("text", "");
                        SharedPreferences p = context.getApplicationContext()
                                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                        int last = p.getInt("anno_version", -1);
                        final boolean isNew = ver > last;
                        if (isNew) {
                            p.edit().putInt("anno_version", ver).apply();
                            // 存入历史
                            String h = p.getString(ANNO_HISTORY, "[]");
                            try {
                                org.json.JSONArray arr = new org.json.JSONArray(h);
                                org.json.JSONObject item = new org.json.JSONObject();
                                item.put("v", ver);
                                item.put("t", text);
                                item.put("ts", System.currentTimeMillis());
                                arr.put(0, item);
                                while (arr.length() > MAX_ANNO_HISTORY) {
                                    arr.remove(arr.length() - 1);
                                }
                                p.edit().putString(ANNO_HISTORY, arr.toString()).apply();
                            } catch (Exception ignored) {}
                        }
                        if (cb != null && text != null && !text.trim().isEmpty()) {
                            final String t = text;
                            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    cb.onAnnouncement(t, isNew);
                                }
                            });
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    /** 返回格式化的历史公告列表（最新在前）。若没有则返回空列表。 */
    public static java.util.List<org.json.JSONObject> getAnnouncementHistory(Context context) {
        java.util.ArrayList<org.json.JSONObject> list = new java.util.ArrayList<>();
        SharedPreferences p = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String h = p.getString(ANNO_HISTORY, "[]");
        try {
            org.json.JSONArray arr = new org.json.JSONArray(h);
            for (int i = 0; i < arr.length(); i++) {
                list.add(arr.getJSONObject(i));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public interface AnnouncementsCallback {
        void onResult(java.util.List<org.json.JSONObject> history);
    }

    /** 从服务器拉取历史公告列表（最新在前，元素含 v/t/ts）。 */
    public static void fetchAnnouncements(final Context context, final AnnouncementsCallback cb) {
        new Thread(new Runnable() {
            public void run() {
                final java.util.List<org.json.JSONObject> list = new java.util.ArrayList<>();
                try {
                    org.json.JSONObject o = httpJson(context, "/api/announcements", null);
                    if (o != null && o.optBoolean("ok", false)) {
                        org.json.JSONArray arr = o.optJSONArray("history");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) {
                                try { list.add(arr.getJSONObject(i)); } catch (Exception ignored) {}
                            }
                        }
                    }
                } catch (Exception ignored) {}
                if (cb != null) {
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        public void run() { cb.onResult(list); }
                    });
                }
            }
        }).start();
    }

    /** 拉取少年文枢专属公告；版本比本地新且非空时回调。 */
    public static void checkWenshuAnnouncement(final Context context, final AnnounceCallback cb) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    org.json.JSONObject o = httpJson(context, "/api/wenshu/announcement", null);
                    if (o != null && o.optBoolean("ok", false)) {
                        int ver = o.optInt("version", 0);
                        String text = o.optString("text", "");
                        SharedPreferences p = context.getApplicationContext()
                                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                        int last = p.getInt("wenshu_anno_version", -1);
                        final boolean isNew = ver > last;
                        if (isNew) {
                            p.edit().putInt("wenshu_anno_version", ver).apply();
                            String h = p.getString(WENSHU_ANNO_HISTORY, "[]");
                            try {
                                org.json.JSONArray arr = new org.json.JSONArray(h);
                                org.json.JSONObject item = new org.json.JSONObject();
                                item.put("v", ver);
                                item.put("t", text);
                                item.put("ts", System.currentTimeMillis());
                                arr.put(0, item);
                                while (arr.length() > MAX_ANNO_HISTORY) {
                                    arr.remove(arr.length() - 1);
                                }
                                p.edit().putString(WENSHU_ANNO_HISTORY, arr.toString()).apply();
                            } catch (Exception ignored) {}
                        }
                        if (cb != null && text != null && !text.trim().isEmpty()) {
                            final String t = text;
                            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    cb.onAnnouncement(t, isNew);
                                }
                            });
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    /** 返回少年文枢本地历史公告列表（最新在前）。 */
    public static java.util.List<org.json.JSONObject> getWenshuAnnouncementHistory(Context context) {
        java.util.ArrayList<org.json.JSONObject> list = new java.util.ArrayList<>();
        SharedPreferences p = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String h = p.getString(WENSHU_ANNO_HISTORY, "[]");
        try {
            org.json.JSONArray arr = new org.json.JSONArray(h);
            for (int i = 0; i < arr.length(); i++) {
                list.add(arr.getJSONObject(i));
            }
        } catch (Exception ignored) {}
        return list;
    }

    /** 从服务器拉取少年文枢历史公告列表（最新在前，元素含 v/t/ts）。 */
    public static void fetchWenshuAnnouncements(final Context context, final AnnouncementsCallback cb) {
        new Thread(new Runnable() {
            public void run() {
                final java.util.List<org.json.JSONObject> list = new java.util.ArrayList<>();
                try {
                    org.json.JSONObject o = httpJson(context, "/api/wenshu/announcements", null);
                    if (o != null && o.optBoolean("ok", false)) {
                        org.json.JSONArray arr = o.optJSONArray("history");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) {
                                try { list.add(arr.getJSONObject(i)); } catch (Exception ignored) {}
                            }
                        }
                    }
                } catch (Exception ignored) {}
                if (cb != null) {
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        public void run() { cb.onResult(list); }
                    });
                }
            }
        }).start();
    }

    // ===================== 账号系统（注册 / 登录 / 手机号 / 账号VIP）=====================

    private static final String KEY_TOKEN = "user_token";
    private static final String KEY_ACCOUNT = "account_username";
    private static final String KEY_PHONE = "account_phone";
    private static final String KEY_HAS_PHONE = "account_has_phone";

    public interface AccountCallback {
        /** ok=是否成功；error=错误信息；username/phone/hasPhone/isVip/expireDate/message=账号信息。 */
        void onResult(boolean ok, String error, String username, String phone,
                      boolean hasPhone, boolean isVip, String expireDate, String message);
    }

    public interface CaptchaCallback {
        void onResult(String question, String captchaId);
    }

    private static SharedPreferences sp(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String getToken(Context context) {
        String t = sp(context).getString(KEY_TOKEN, "");
        return t == null ? "" : t;
    }

    public static boolean hasAccount(Context context) {
        return !getToken(context).isEmpty();
    }

    public static String getAccountName(Context context) {
        return sp(context).getString(KEY_ACCOUNT, "");
    }

    public static String getAccountPhone(Context context) {
        return sp(context).getString(KEY_PHONE, "");
    }

    public static boolean hasAccountPhone(Context context) {
        return sp(context).getBoolean(KEY_HAS_PHONE, false);
    }

    public static void logout(Context context) {
        sp(context).edit().remove(KEY_TOKEN).remove(KEY_ACCOUNT)
                .remove(KEY_PHONE).remove(KEY_HAS_PHONE).apply();
        clearVip(context);
    }

    private static void saveAccount(Context context, String username, String phone, boolean hasPhone) {
        sp(context).edit().putString(KEY_ACCOUNT, username == null ? "" : username)
                .putString(KEY_PHONE, phone == null ? "" : phone)
                .putBoolean(KEY_HAS_PHONE, hasPhone).apply();
    }

    /** 简单 HTTP JSON 请求：body 为 null 时用 GET，否则 POST。返回 null 表示网络/解析失败。 */
    private static org.json.JSONObject httpJson(Context context, String path, org.json.JSONObject body) {
        java.util.LinkedHashSet<String> bases = new java.util.LinkedHashSet<>();
        // 优先走标准 80 端口（nginx 反代到 18081），避免手机无法访问非标准端口
        bases.add(ALT_SERVER);
        String s = getServer(context);
        if (s != null && !s.isEmpty()) bases.add(s);
        bases.add(DEFAULT_SERVER);
        for (String b : bases) {
            org.json.JSONObject o = httpJsonOne(b, path, body);
            if (o != null) return o;
        }
        return null;
    }

    private static org.json.JSONObject httpJsonOne(String base, String path, org.json.JSONObject body) {
        java.net.HttpURLConnection conn = null;
        try {
            java.net.URL url = new java.net.URL(base + path);
            conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(6000);
            if (body != null) {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                byte[] data = body.toString().getBytes("UTF-8");
                conn.setFixedLengthStreamingMode(data.length);
                conn.getOutputStream().write(data);
            }
            int code = conn.getResponseCode();
            java.io.InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String text = "";
            if (is != null) {
                java.util.Scanner sc = new java.util.Scanner(is, "UTF-8").useDelimiter("\\A");
                text = sc.hasNext() ? sc.next() : "";
                sc.close();
            }
            return new org.json.JSONObject(text);
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static void postAccount(final Context context, final String path,
                                    final org.json.JSONObject body, final AccountCallback cb) {
        new Thread(new Runnable() {
            public void run() {
                handleAccountJson(context, httpJson(context, path, body), cb);
            }
        }).start();
    }

    private static void handleAccountJson(final Context context, final org.json.JSONObject o,
                                          final AccountCallback cb) {
        final boolean ok;
        final String error, username, phone, expireDate, message;
        final boolean hasPhone, isVip;
        if (o == null) {
            ok = false;
            error = "网络错误，请检查网络后重试";
            username = getAccountName(context);
            phone = getAccountPhone(context);
            hasPhone = hasAccountPhone(context);
            isVip = false;
            expireDate = "";
            message = "";
        } else {
            ok = o.optBoolean("ok", false);
            error = o.optString("error", "");
            username = o.optString("username", getAccountName(context));
            phone = o.optString("phone", getAccountPhone(context));
            hasPhone = o.optBoolean("has_phone", phone != null && !phone.isEmpty());
            isVip = o.optBoolean("is_vip", false);
            expireDate = o.optString("vip_expire_date", "");
            message = o.optString("message", "");
            if (ok) {
                String tok = o.optString("token", "");
                if (tok != null && !tok.isEmpty()) sp(context).edit().putString(KEY_TOKEN, tok).apply();
                saveAccount(context, username, phone, hasPhone);
                if (isVip) {
                    long exp = o.optLong("vip_expire_time", 0L);
                    if (exp > 0) setVipExpireAt(context, exp);
                } else {
                    clearVip(context);
                }
            }
        }
        if (cb != null) {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                public void run() {
                    cb.onResult(ok, error, username, phone, hasPhone, isVip, expireDate, message);
                }
            });
        }
    }

    /** 注册（需手机号 + 算术验证码），成功后自动登录并保存 token。 */
    public static void register(Context context, String username, String password, String phone,
                                String captchaId, String captchaAnswer, AccountCallback cb) {
        org.json.JSONObject b = new org.json.JSONObject();
        try {
            b.put("username", username).put("password", password).put("phone", phone)
                    .put("captcha_id", captchaId).put("captcha_answer", captchaAnswer)
                    .put("device_id", getDeviceId(context));
        } catch (Exception ignored) {}
        postAccount(context, "/api/register", b, cb);
    }

    public static void login(Context context, String username, String password, AccountCallback cb) {
        org.json.JSONObject b = new org.json.JSONObject();
        try {
            b.put("username", username).put("password", password)
                    .put("device_id", getDeviceId(context));
        } catch (Exception ignored) {}
        postAccount(context, "/api/login", b, cb);
    }

    /** 拉取当前登录账号信息（VIP、手机号等）。 */
    public static void fetchUserInfo(final Context context, final AccountCallback cb) {
        final String tok = getToken(context);
        if (tok.isEmpty()) {
            if (cb != null) cb.onResult(false, "尚未登录", "", "", false, false, "", "");
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                org.json.JSONObject o = null;
                try {
                    o = httpJson(context, "/api/user/info?token="
                            + java.net.URLEncoder.encode(tok, "UTF-8"), null);
                } catch (Exception ignored) {}
                handleAccountJson(context, o, cb);
            }
        }).start();
    }

    /** 补充绑定手机号（老账号一次性补填）。 */
    public static void bindPhone(Context context, String phone, AccountCallback cb) {
        org.json.JSONObject b = new org.json.JSONObject();
        try {
            b.put("token", getToken(context)).put("phone", phone);
        } catch (Exception ignored) {}
        postAccount(context, "/api/user/bind_phone", b, cb);
    }

    /** 获取注册用算术验证码。 */
    public static void fetchCaptcha(final Context context, final CaptchaCallback cb) {
        new Thread(new Runnable() {
            public void run() {
                final org.json.JSONObject o = httpJson(context, "/api/captcha", null);
                final String q = o != null ? o.optString("question", "") : "";
                final String id = o != null ? o.optString("captcha_id", "") : "";
                new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        if (cb != null) cb.onResult(q, id);
                    }
                });
            }
        }).start();
    }

    /** 从服务器同步 VIP 状态并缓存到本地（供 isVip 判断）；以服务器返回的 expire_at 为准。 */
    public static void syncVip(final Context context, final SyncCallback onDone) {
        // 设备码匹配 VIP：以本机设备码向服务器查询状态
        final String dev = getDeviceId(context);
        new Thread(new Runnable() {
            public void run() {
                boolean connected = false;
                boolean isVip = false;
                String expireTime = "";
                String message = "";
                try {
                    org.json.JSONObject o = httpJson(context, "/api/vip/status?device_id="
                            + java.net.URLEncoder.encode(dev, "UTF-8"), null);
                    if (o != null && o.optBoolean("ok", false)) {
                        connected = true;
                        isVip = o.optBoolean("is_vip", false);
                        expireTime = o.optString("expire_time", "");
                        message = o.optString("message", "");
                        if (isVip) {
                            long exp = o.optLong("expire_at", 0L);
                            if (exp <= 0) {
                                int days = o.optInt("remain_days", 0);
                                exp = System.currentTimeMillis() + (long) days * 86400000L;
                            }
                            setVipExpireAt(context, exp);
                        } else {
                            clearVip(context);
                        }
                    }
                } catch (Exception ignored) {
                }
                final boolean c = connected, v = isVip;
                final String et = expireTime, msg = message;
                if (onDone != null) {
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                        public void run() {
                            onDone.onSynced(c, v, et, msg);
                        }
                    });
                }
            }
        }).start();
    }
}

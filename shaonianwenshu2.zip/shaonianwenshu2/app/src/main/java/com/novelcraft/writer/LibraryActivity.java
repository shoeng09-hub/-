package com.novelcraft.writer;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import com.example.liquidglass.LiquidGlassButton;
import android.widget.ListView;
import android.widget.TextView;
import android.media.MediaPlayer;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import com.novelcraft.writer.SaveHelper.NovelInfo;

public class LibraryActivity extends android.app.Activity {

    public static final int RESULT_NEW = 99;

    private ListView listView;
    private TextView tvEmpty, tvHeading;
    private LiquidGlassButton btnBack, btnAction;

    private List<NovelInfo> novels = new ArrayList<>();
    private List<String> chapterTitles = new ArrayList<>();
    private List<String> displayTitles = new ArrayList<>();
    private List<String> chapterReviews = new ArrayList<>();
    private NovelInfo current;
    private boolean chaptersMode = false;
    private boolean hasOutline = false;
    private NovelService service;
    private MediaPlayer mClickPlayer;
    private LanShareServer lanServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);
        ThemeManager.apply(this);
        service = new NovelService(this);
        listView = findViewById(R.id.listView);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvHeading = findViewById(R.id.tvHeading);
        btnBack = findViewById(R.id.btnBack);
        btnAction = findViewById(R.id.btnAction);

        setupBottomNav();

        btnBack.setOnClickListener(v -> { playClickSound();
            if (chaptersMode) {
                chaptersMode = false;
                refresh();
            } else {
                finish();
            }
        });

        btnAction.setOnClickListener(v -> { playClickSound();
            if (chaptersMode && current != null) {
                continueWriting(current);
            } else if (!novels.isEmpty()) {
                // 书库列表页且已有作品：自动选中第一本，进入续写模式，而不是直接新建
                current = novels.get(0);
                hasOutline = !SaveHelper.getOutline(current.dir).isEmpty();
                chapterTitles = SaveHelper.chapterTitles(current.dir);
                chaptersMode = true;
                refresh();
            } else {
                setResult(RESULT_NEW);
                finish();
            }
        });

        listView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            if (chaptersMode) {
                if (hasOutline && position == 0) {
                    openOutline();
                    return;
                }
                int idx = position - (hasOutline ? 1 : 0);
                openChapter(idx);
            } else {
                current = novels.get(position);
                hasOutline = !SaveHelper.getOutline(current.dir).isEmpty();
                chapterTitles = SaveHelper.chapterTitles(current.dir);
                chaptersMode = true;
                refresh();
            }
        });

        listView.setOnItemLongClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            if (chaptersMode) {
                int idx = position - (hasOutline ? 1 : 0);
                if (hasOutline && position == 0) {
                    return false;
                }
                if (idx < 0 || idx >= chapterTitles.size()) return false;
                String title = chapterTitles.get(idx);
                android.widget.PopupMenu pm = new android.widget.PopupMenu(this, view);
                pm.getMenu().add(R.string.btn_delete);
                pm.setOnMenuItemClickListener(item -> {
                    new AlertDialog.Builder(this)
                            .setTitle(R.string.btn_delete)
                            .setMessage(getString(R.string.delete_confirm_chapter, title))
                            .setPositiveButton(R.string.btn_delete, (d, w) -> {
                                SaveHelper.deleteChapter(current.dir, idx);
                                chapterTitles = SaveHelper.chapterTitles(current.dir);
                                refresh();
                            })
                            .setNegativeButton(R.string.btn_cancel, null)
                            .show();
                    return true;
                });
                pm.show();
            } else {
                if (position < 0 || position >= novels.size()) return false;
                NovelInfo n = novels.get(position);
                android.widget.PopupMenu pm = new android.widget.PopupMenu(this, view);
                pm.getMenu().add(0, 1, 0, R.string.lan_share);
                pm.getMenu().add(0, 2, 1, R.string.btn_delete);
                pm.setOnMenuItemClickListener(item -> {
                    if (item.getItemId() == 1) {
                        lanShare(n);
                        return true;
                    }
                    new AlertDialog.Builder(this)
                            .setTitle(R.string.btn_delete)
                            .setMessage(getString(R.string.delete_confirm_novel, "《" + n.title + "》"))
                            .setPositiveButton(R.string.btn_delete, (d, w) -> {
                                SaveHelper.deleteNovel(n.dir);
                                novels = SaveHelper.listLibrary(this);
                                refresh();
                            })
                            .setNegativeButton(R.string.btn_cancel, null)
                            .show();
                    return true;
                });
                pm.show();
            }
            return true;
        });
    }

    private void setupBottomNav() {
        GlassNav.setup(this, 1, index -> {
            playClickSound();
            GlassNav.navigate(this, index);
        });
    }

    private void goMain(String action) {
        Intent it = new Intent(this, MainActivity.class);
        it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (action != null) it.putExtra("action", action);
        startActivity(it);
    }

    private void continueWriting(NovelInfo novel) {
        String content = SaveHelper.novelContent(novel.dir);
        if (content == null || content.isEmpty()) {
            android.widget.Toast.makeText(this, R.string.library_empty, android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        Intent data = new Intent();
        data.putExtra("title", novel.title);
        data.putExtra("content", content);
        data.putExtra("genre", novel.genre);
        data.putExtra("style", novel.style);
        data.putExtra("chapterLength", novel.chapterLength);
        data.putExtra("totalChapters", novel.totalChapters);
        data.putExtra("dir", novel.dir.getAbsolutePath());
        setResult(RESULT_OK, data);
        finish();
    }

    private void openOutline() {
        if (current == null) return;
        Intent it = new Intent(this, OutlineActivity.class);
        it.putExtra("title", current.title);
        it.putExtra("genre", current.genre);
        it.putExtra("style", current.style);
        it.putExtra("totalChapters", current.totalChapters);
        it.putExtra("dir", current.dir.getAbsolutePath());
        startActivity(it);
    }

    private void openChapter(int idx) {
        if (current == null || idx < 0 || idx >= chapterTitles.size()) return;
        String content = SaveHelper.chapterContent(current.dir, idx);
        String title = chapterTitles.get(idx);
        Intent it = new Intent(this, ChapterContentActivity.class);
        it.putExtra("title", title);
        it.putExtra("content", content);
        startActivity(it);
    }

    private void showReviewDialog(int idx, String review) {
        String title = (idx >= 0 && idx < chapterTitles.size()) ? chapterTitles.get(idx) : "";
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.review_record_title, title))
                .setMessage(review)
                .setPositiveButton(R.string.btn_ai_revise, (d, w) -> aiReviseChapter(idx, review))
                .setNeutralButton(R.string.btn_view_chapter, (d, w) -> openChapter(idx))
                .setNegativeButton(R.string.btn_close, null)
                .show();
    }

    private void aiReviseChapter(int idx, String review) {
        if (current == null || idx < 0 || idx >= chapterTitles.size() || service == null) return;
        if (!service.hasValidApiKey()) {
            android.widget.Toast.makeText(this, R.string.error_api_key, android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        final String ct = chapterTitles.get(idx);
        final String cc = SaveHelper.chapterContent(current.dir, idx);
        android.widget.Toast.makeText(this, R.string.toast_revising, android.widget.Toast.LENGTH_LONG).show();
        service.reviseChapter(current.title,
                SaveHelper.getHeroName(current.dir),
                SaveHelper.getMainContent(current.dir),
                SaveHelper.getOutline(current.dir),
                ct, cc, review,
                new NovelService.ChatCallback() {
                    @Override
                    public void onReply(String reply) {
                        String cleaned = reply == null ? "" : reply.trim();
                        if (!cleaned.isEmpty()) {
                            SaveHelper.updateChapter(current.dir, idx, cleaned);
                        }
                        chapterTitles = SaveHelper.chapterTitles(current.dir);
                        refresh();
                        android.widget.Toast.makeText(LibraryActivity.this, R.string.revise_done, android.widget.Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onError(String error) {
                        android.widget.Toast.makeText(LibraryActivity.this, getString(R.string.progress_failed, error), android.widget.Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void reviewChapter(int idx) {
        if (current == null || idx < 0 || idx >= chapterTitles.size()) return;
        if (service == null) service = new NovelService(this);
        if (!service.hasValidApiKey()) {
            android.widget.Toast.makeText(this, R.string.error_api_key, android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        final String ct = chapterTitles.get(idx);
        final String cc = SaveHelper.chapterContent(current.dir, idx);
        android.widget.Toast.makeText(this, R.string.toast_reviewing, android.widget.Toast.LENGTH_LONG).show();
        service.review(ct, cc, new NovelService.NovelCallback() {
            @Override
            public void onStatus(String status) {
            }

            @Override
            public void onContent(String fullText, boolean done) {
                if (done) {
                    SaveHelper.updateChapterReview(current.dir, idx, fullText);
                    chapterTitles = SaveHelper.chapterTitles(current.dir);
                    refresh();
                    showReviewDialog(idx, fullText);
                }
            }

            @Override
            public void onError(String error) {
                android.widget.Toast.makeText(LibraryActivity.this, getString(R.string.progress_failed, error), android.widget.Toast.LENGTH_LONG).show();
            }
        });
    }

    private void playClickSound() {
        try {
            if (mClickPlayer != null) {
                mClickPlayer.release();
                mClickPlayer = null;
            }
            mClickPlayer = MediaPlayer.create(this, R.raw.click_sound);
            if (mClickPlayer != null) {
                mClickPlayer.setOnCompletionListener(m -> {
                    m.release();
                    mClickPlayer = null;
                });
                mClickPlayer.start();
            }
        } catch (Exception ignored) {
        }
    }

    private void lanShare(NovelInfo n) {
        String content = SaveHelper.novelContent(n.dir);
        if (content == null || content.trim().isEmpty()) {
            android.widget.Toast.makeText(this, R.string.lan_share_empty, android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (lanServer != null) {
                lanServer.stop();
            }
            lanServer = new LanShareServer();
            lanServer.start(n.title, content);
        } catch (Exception e) {
            android.widget.Toast.makeText(this,
                    getString(R.string.lan_share_failed, String.valueOf(e.getMessage())),
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }

        android.widget.ImageView qr = new android.widget.ImageView(this);
        android.graphics.Bitmap bmp = LanShareServer.makeQr(lanServer.getDeepLink(), 640);
        if (bmp != null) {
            qr.setImageBitmap(bmp);
        }
        qr.setAdjustViewBounds(true);
        qr.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        qr.setPadding(16, 16, 16, 16);

        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(32, 16, 32, 8);
        box.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        box.addView(qr, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));

        android.widget.TextView tip = new android.widget.TextView(this);
        tip.setText(R.string.lan_share_tip);
        tip.setTextColor(0xFFB0B0B0);
        tip.setTextSize(13);
        tip.setGravity(android.view.Gravity.CENTER);
        tip.setPadding(0, 12, 0, 12);
        box.addView(tip);

        android.widget.TextView urlView = new android.widget.TextView(this);
        urlView.setText(lanServer.getUrl());
        urlView.setTextColor(0xFFC9A961);
        urlView.setTextSize(14);
        urlView.setGravity(android.view.Gravity.CENTER);
        box.addView(urlView);

        final LanShareServer server = lanServer;
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.lan_share_title, "《" + n.title + "》"))
                .setView(box)
                .setPositiveButton(R.string.btn_copy, (d, w) -> {
                    android.content.ClipboardManager cm =
                            (android.content.ClipboardManager) getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("lan", server.getUrl()));
                    android.widget.Toast.makeText(this, R.string.copied, android.widget.Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.btn_close, (d, w) -> server.stop())
                .setOnDismissListener(d -> server.stop())
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (lanServer != null) {
            lanServer.stop();
            lanServer = null;
        }
        if (service != null) service.shutdown();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ThemeManager.apply(this);
        GlassNav.correct(this);
        new Thread(() -> {
            SaveHelper.importDownloads(this);
            final List<NovelInfo> result = SaveHelper.listLibrary(this);
            runOnUiThread(() -> {
                novels = result;
                chaptersMode = false;
                refresh();
            });
        }).start();
    }

    private void refresh() {
        if (chaptersMode && current != null) {
            tvHeading.setText(current.title);
            btnAction.setText(getString(R.string.btn_continue_write));
            displayTitles.clear();
            chapterReviews.clear();
            if (hasOutline) {
                displayTitles.add("《大纲》");
            }
            for (int i = 0; i < chapterTitles.size(); i++) {
                String review = SaveHelper.getChapterReview(current.dir, i);
                chapterReviews.add(review);
                String t = chapterTitles.get(i);
                if (!review.isEmpty()) t = t + "　✎";
                displayTitles.add(t);
            }
            ChapterAdapter a = new ChapterAdapter();
            listView.setAdapter(a);
            boolean empty = displayTitles.isEmpty();
            tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            listView.setVisibility(empty ? View.GONE : View.VISIBLE);
        } else {
            tvHeading.setText(R.string.library_title);
            btnAction.setText(getString(R.string.btn_new));
            List<String> items = new ArrayList<>();
            for (NovelInfo n : novels) {
                items.add("《" + n.title + "》  ·  共 " + n.chapterCount + " 章");
            }
            ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
            listView.setAdapter(a);
            boolean empty = novels.isEmpty();
            tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            listView.setVisibility(empty ? View.GONE : View.VISIBLE);
        }
    }

    private class ChapterAdapter extends android.widget.BaseAdapter {
        @Override
        public int getCount() {
            return displayTitles.size();
        }

        @Override
        public Object getItem(int position) {
            return displayTitles.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, android.view.ViewGroup parent) {
            View v = convertView;
            ViewHolder h;
            if (v == null) {
                v = getLayoutInflater().inflate(R.layout.row_chapter, parent, false);
                h = new ViewHolder();
                h.title = v.findViewById(R.id.tvChapTitle);
                h.snippet = v.findViewById(R.id.tvChapSnippet);
                h.pen = v.findViewById(R.id.ivReviewPen);
                v.setTag(h);
            } else {
                h = (ViewHolder) v.getTag();
            }
            boolean isOutline = hasOutline && position == 0;
            int idx = position - (hasOutline ? 1 : 0);
            h.title.setText(displayTitles.get(position));
            if (isOutline || idx < 0 || idx >= chapterTitles.size()) {
                h.pen.setVisibility(View.GONE);
                h.snippet.setVisibility(View.GONE);
            } else {
                h.pen.setVisibility(View.VISIBLE);
                h.pen.setTag(idx);
                h.pen.setOnClickListener(vv -> {
                    Object tag = vv.getTag();
                    if (tag instanceof Integer) reviewChapter((Integer) tag);
                });
                String content = SaveHelper.chapterContent(current.dir, idx);
                String snip = (content == null) ? "" : content.trim();
                if (snip.length() > 40) snip = snip.substring(0, 40);
                h.snippet.setText(snip);
                h.snippet.setVisibility(snip.isEmpty() ? View.GONE : View.VISIBLE);
            }
            return v;
        }

        private class ViewHolder {
            TextView title;
            TextView snippet;
            android.widget.ImageView pen;
        }
    }
}

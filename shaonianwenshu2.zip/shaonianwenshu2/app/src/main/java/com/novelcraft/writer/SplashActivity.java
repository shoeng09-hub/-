package com.novelcraft.writer;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;

/** 启动页：展示 Logo 与「少年文枢」，短暂停留后进入主界面。 */
public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MediaPlayer.create(this, R.raw.splash_sound).start();
        setContentView(R.layout.activity_splash);
        ThemeManager.apply(this);
        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }, 1200);
    }
}

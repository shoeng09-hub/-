package com.novelcraft.writer;

import android.content.Intent;
import android.os.Bundle;

public class WorkbenchActivity extends android.app.Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workbench);
        ThemeManager.apply(this);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.wbOutline).setOnClickListener(v -> goMain("outline"));
        findViewById(R.id.wbChat).setOnClickListener(v -> goMain("chat"));
        findViewById(R.id.wbReview).setOnClickListener(v -> goMain("review"));
        findViewById(R.id.wbBatch).setOnClickListener(v -> goMain("batch"));
    }

    private void goMain(String action) {
        Intent it = new Intent(this, MainActivity.class);
        it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        it.putExtra("action", action);
        startActivity(it);
    }
}

package com.novelcraft.writer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import com.novelcraft.writer.NovelService.Chapter;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/** 处理 shaonianwenshu://import?... 深链：从局域网分享端下载小说并直接收录进书库。 */
public class LanImportActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.apply(this);

        Intent intent = getIntent();
        Uri data = intent == null ? null : intent.getData();
        if (data == null) {
            finish();
            return;
        }
        String rawTitle = data.getQueryParameter("t");
        String rawUrl = data.getQueryParameter("u");
        if (rawUrl == null || rawUrl.trim().isEmpty()) {
            Toast.makeText(this, R.string.lan_import_bad, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        final String title = (rawTitle == null || rawTitle.trim().isEmpty()) ? "局域网分享" : rawTitle.trim();
        final String url = rawUrl.trim();

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.lan_import_title)
                .setMessage(getString(R.string.lan_importing, title))
                .setCancelable(false)
                .show();

        new Thread(() -> {
            String content = null;
            String error = null;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(30000);
                int code = conn.getResponseCode();
                if (code >= 200 && code < 300) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                        char[] buf = new char[8192];
                        int n;
                        while ((n = br.read(buf)) > 0) {
                            sb.append(buf, 0, n);
                        }
                    }
                    content = sb.toString();
                } else {
                    error = "HTTP " + code;
                }
                conn.disconnect();
            } catch (Exception e) {
                error = String.valueOf(e.getMessage());
            }

            final String fContent = content;
            final String fError = error;
            runOnUiThread(() -> {
                try {
                    dialog.dismiss();
                } catch (Exception ignored) {
                }
                if (fContent == null || fContent.trim().isEmpty()) {
                    Toast.makeText(this,
                            getString(R.string.lan_import_failed, fError == null ? "内容为空" : fError),
                            Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                try {
                    List<Chapter> chapters = SaveHelper.splitChapters(fContent);
                    SaveHelper.saveLibrary(this, title, chapters, "", "", 1000, 0, null);
                    Toast.makeText(this, getString(R.string.lan_import_done, title), Toast.LENGTH_LONG).show();
                    startActivity(new Intent(this, LibraryActivity.class));
                } catch (Exception e) {
                    Toast.makeText(this,
                            getString(R.string.lan_import_failed, String.valueOf(e.getMessage())),
                            Toast.LENGTH_LONG).show();
                }
                finish();
            });
        }).start();
    }
}

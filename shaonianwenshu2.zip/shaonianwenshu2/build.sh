#!/usr/bin/env bash
# ============================================================
#  少年文枢 · 一键构建脚本
#  用法：
#    ./build.sh              # 构建 release（已签名，可直接安装）
#    ./build.sh debug        # 构建 debug
#    ./build.sh release --clean   # 先清理再构建
#  产物输出到：app/build/outputs/apk/<buildType>/
#  并复制一份到项目根目录：少年文枢_v1.0.2_<buildType>.apk
# ============================================================
set -euo pipefail

cd "$(dirname "$0")"

BUILD_TYPE="${1:-release}"
shift || true
EXTRA_ARGS=("$@")

echo "==> 构建类型: $BUILD_TYPE"

# ---------- 0. 修复 locale（关键！）----------
# 很多设备的 locale 是 POSIX/ASCII，JVM 的 sun.jnu.encoding 会退化成
# ANSI_X3.4-1968，导致它无法处理路径里的中文字符，直接抛：
#   InvalidPathException: Malformed input or input contains unmappable characters
# 这正是「构建工具莫名其妙崩溃」的常见真凶。这里强制切到 UTF-8 locale。
if [ "${LC_ALL:-}" != "C.UTF-8" ] && [ "${LANG:-}" != "C.UTF-8" ]; then
  if locale -a 2>/dev/null | grep -qx "C.utf8\|C.UTF-8"; then
    export LC_ALL="C.UTF-8"
    export LANG="C.UTF-8"
    echo "==> locale: 强制设为 C.UTF-8（修复中文路径崩溃）"
  else
    echo "!! 警告: 系统没有 C.UTF-8 locale。若后续报 InvalidPathException，"
    echo "   请把项目移到纯英文路径后再构建。"
  fi
fi

# 若当前目录路径含非 ASCII 字符且 JVM 仍无法处理，直接提示并优雅降级
case "$(pwd)" in
  *[!a-zA-Z0-9_./-]*)
    if ! java -XshowSettings:properties -version 2>&1 | grep -q "sun.jnu.encoding = UTF-8"; then
      echo "!! 警告: 当前路径含非 ASCII 字符且 JVM locale 非 UTF-8。"
      echo "   建议把项目复制到纯英文路径，例如: cp -r \"\$PWD\" ~/novelcraft-build"
    fi
    ;;
esac

# ---------- 1. 定位 JDK ----------
# 优先使用 JAVA_HOME；其次尝试常见安装位置；最后退回 PATH 上的 java。
find_java_home() {
  if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/javac" ]; then
    echo "$JAVA_HOME"; return
  fi
  local c
  for c in \
    /usr/lib/jvm/java-21-openjdk-arm64 \
    /usr/lib/jvm/java-17-openjdk-arm64 \
    /usr/lib/jvm/default-java \
    /data/data/com.termux/files/usr/lib/jvm/java-21-openjdk \
    /data/data/com.termux/files/usr/lib/jvm/java-17-openjdk \
    "/Applications/Android Studio.app/Contents/jbr/Contents/Home" \
    "/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home" \
    "/Library/Java/JavaVirtualMachines/jdk-21.jdk/Contents/Home" \
    "/usr/lib/jvm/temurin-21-jdk-amd64" \
    "/usr/lib/jvm/java-21-openjdk-amd64" \
    "/usr/lib/jvm/java-17-openjdk-amd64" ; do
    if [ -x "$c/bin/javac" ]; then echo "$c"; return; fi
  done
  # 用 PATH 上的 javac 反推 JAVA_HOME
  local jc; jc="$(command -v javac 2>/dev/null || true)"
  if [ -n "$jc" ]; then
    local real; real="$(readlink -f "$jc" 2>/dev/null || echo "$jc")"
    echo "$(dirname "$(dirname "$real")")"; return
  fi
  echo ""
}

JAVA_HOME_DETECTED="$(find_java_home)"
if [ -n "$JAVA_HOME_DETECTED" ]; then
  echo "==> JDK: $JAVA_HOME_DETECTED"
  JAVA_HOME="$JAVA_HOME_DETECTED"
  export JAVA_HOME
  export PATH="$JAVA_HOME/bin:$PATH"
else
  echo "!! 警告: 未找到 JDK，请先安装 JDK 17 或 21"
fi

# ---------- 2. 定位 Android SDK ----------
find_sdk() {
  if [ -f local.properties ]; then
    local d; d="$(sed -n 's/^[[:space:]]*sdk\.dir[[:space:]]*=[[:space:]]*//p' local.properties | tail -1 | tr -d '\r')"
    if [ -n "$d" ] && [ -d "$d" ]; then echo "$d"; return; fi
  fi
  for d in "${ANDROID_SDK_ROOT:-}" "${ANDROID_HOME:-}" \
           /opt/android-sdk "$HOME/Android/Sdk" "$HOME/Library/Android/sdk" \
           "$HOME/AppData/Local/Android/Sdk"; do
    if [ -n "$d" ] && [ -d "$d" ]; then echo "$d"; return; fi
  done
  echo ""
}

SDK_DIR="$(find_sdk)"
if [ -z "$SDK_DIR" ]; then
  echo "!! 错误: 找不到 Android SDK。"
  echo "   请在 local.properties 写入 sdk.dir=/你的/sdk/路径"
  exit 1
fi
echo "==> SDK: $SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export ANDROID_HOME="$SDK_DIR"

# ---------- 3. 定位 aapt2 ----------
# AGP 默认从 Maven 下载 aapt2；离线/墙内环境常失败，因此本地有就直接用。
#
# 重要：SDK 里各版本的 aapt2 架构不一定匹配本机！
# 例如官方 SDK 的 build-tools/36.0.0/aapt2 是 x86-64 二进制，
# 在 arm64 的手机/模拟器上运行会直接 "Illegal instruction" 崩掉，
# 表现为 Gradle 报 "AAPT2 Daemon startup failed"。
# 所以这里逐个候选实际执行一次探测，取第一个能跑通的。
find_aapt2() {
  local bd cand
  # 优先 35.0.0（与本项目 compileSdk 35 匹配），再按版本号从新到旧
  local dirs
  dirs="$(ls -1d "$SDK_DIR/build-tools"/*/ 2>/dev/null | sort -V -r)"
  [ -d "$SDK_DIR/build-tools/35.0.0/" ] && dirs="$SDK_DIR/build-tools/35.0.0/
$dirs"
  for bd in $dirs; do
    cand="${bd}aapt2"
    [ -x "$cand" ] || continue
    if "$cand" version >/dev/null 2>&1; then
      echo "$cand"; return
    fi
  done
  echo ""
}
AAPT2="$(find_aapt2)"
if [ -n "$AAPT2" ]; then
  echo "==> aapt2: $AAPT2"
  EXTRA_ARGS+=("-Pandroid.aapt2FromMavenOverride=$AAPT2")
else
  echo "!! 警告: 未找到可用的 aapt2，将回退到 AGP 从 Maven 下载"
fi

# ---------- 4. 执行构建 ----------
GRADLE_ARGS=(":app:assemble${BUILD_TYPE^}")

# ---- 关键：把工程同步到「纯英文路径」再构建 ----
# 原因：Gradle / AGP / Kotlin 编译器在「中文路径 + Android 外部存储(SD卡)」下
# 极易出现 InvalidPathException、文件锁失败、daemon 崩溃等问题。
# 同步到 ~/novelcraft-build 这类纯英文路径构建，是最稳、最通用的做法。
SRC_DIR="$(pwd)"
BUILD_DIR="${BUILD_DIR:-$HOME/novelcraft-build}"

# 判断当前路径是否「不安全」：含非 ASCII 字符，或位于外部存储
needs_copy=0
case "$SRC_DIR" in
  *[!a-zA-Z0-9_./-]*) needs_copy=1 ;;
esac
case "$SRC_DIR" in
  /storage/*|/sdcard/*|/mnt/sdcard/*) needs_copy=1 ;;
esac
# 若用户显式指定了 BUILD_DIR，则始终使用它
if [ -n "${BUILD_DIR_OVERRIDE:-}" ]; then
  BUILD_DIR="$BUILD_DIR_OVERRIDE"; needs_copy=1
fi

if [ "$needs_copy" = "1" ]; then
  echo "==> 当前路径不适合直接构建，改为同步到纯英文路径构建："
  echo "    $SRC_DIR  ->  $BUILD_DIR"
  mkdir -p "$BUILD_DIR"
  # 先清掉旧的 app/build，避免 release/debug 产物互相干扰
  rm -rf "$BUILD_DIR/app/build" 2>/dev/null || true
  # 同步源码（排除构建产物与版本库）
  for item in build.gradle settings.gradle gradle.properties gradlew gradlew.bat gradle local.properties keystore.properties keystore proguard-rules.pro; do
    [ -e "$SRC_DIR/$item" ] && cp -rf "$SRC_DIR/$item" "$BUILD_DIR/" 2>/dev/null || true
  done
  # 同步 app 源码，但排除 app/build
  if [ -d "$SRC_DIR/app" ]; then
    rm -rf "$BUILD_DIR/app"
    mkdir -p "$BUILD_DIR/app"
    for sub in src build.gradle libs; do
      [ -e "$SRC_DIR/app/$sub" ] && cp -rf "$SRC_DIR/app/$sub" "$BUILD_DIR/app/" 2>/dev/null || true
    done
  fi
  # SD 卡 / FAT 文件系统不保留执行位，这里显式补上
  chmod +x "$BUILD_DIR/gradlew" 2>/dev/null || true
  cd "$BUILD_DIR"
  echo "==> 已在 $BUILD_DIR 开始构建"
else
  echo "==> 直接在当前目录构建"
fi

echo "==> 执行: ./gradlew ${GRADLE_ARGS[*]} ${EXTRA_ARGS[*]}"
echo

if [ -x ./gradlew ]; then
  ./gradlew "${GRADLE_ARGS[@]}" "${EXTRA_ARGS[@]}"
elif command -v gradle >/dev/null 2>&1; then
  gradle "${GRADLE_ARGS[@]}" "${EXTRA_ARGS[@]}"
else
  echo "!! 错误: 找不到 gradlew，也找不到全局 gradle"
  exit 1
fi

# ---------- 5. 收集产物 ----------
OUT_DIR="app/build/outputs/apk/$BUILD_TYPE"
if [ ! -d "$OUT_DIR" ]; then
  echo "!! 未找到产物目录 $OUT_DIR"; exit 1
fi

APK="$(ls -1 "$OUT_DIR"/*.apk 2>/dev/null | grep -v 'unsigned' | head -1 || true)"
if [ -z "$APK" ]; then
  APK="$(ls -1 "$OUT_DIR"/*.apk 2>/dev/null | head -1 || true)"
fi
if [ -z "$APK" ]; then
  echo "!! 未找到 APK"; exit 1
fi

VERSION_NAME="$(sed -n 's/^[[:space:]]*versionName[[:space:]]*=[[:space:]]*"\(.*\)"/\1/p' app/build.gradle | head -1)"
VERSION_NAME="${VERSION_NAME:-app}"
# 固定文件名，每次构建直接覆盖旧包，避免堆积一堆版本 APK
FINAL="少年文枢_${BUILD_TYPE}.apk"
# 把产物拷回原始项目目录（构建可能发生在纯英文临时目录）
cp -f "$APK" "$SRC_DIR/$FINAL"

echo
echo "============================================"
echo " 构建成功 ✅"
echo " APK: $SRC_DIR/$FINAL"
echo " 大小: $(du -h "$SRC_DIR/$FINAL" | cut -f1)"
echo "============================================"

# ---------- 6. 签名自检 ----------
# 同样要挑「架构匹配本机、且能真正跑起来」的 apksigner。
find_tool() {
  local name="$1"; local bd cand dirs
  dirs="$(ls -1d "$SDK_DIR/build-tools"/*/ 2>/dev/null | sort -V -r)"
  for bd in $dirs; do
    cand="${bd}${name}"
    [ -x "$cand" ] || continue
    if "$cand" --version >/dev/null 2>&1 || "$cand" version >/dev/null 2>&1; then
      echo "$cand"; return
    fi
  done
  echo ""
}
APKSIGNER="$(find_tool apksigner)"
if [ -n "$APKSIGNER" ]; then
  echo
  echo "==> 签名校验 (apksigner: $APKSIGNER):"
  "$APKSIGNER" verify --print-certs "$SRC_DIR/$FINAL" 2>&1 | head -8 || echo "(apksigner 校验异常，请手动检查)"
else
  echo
  echo "==> 提示: 未找到可用的 apksigner，跳过签名自检"
fi
echo
echo "安装命令: adb install -r \"$FINAL\""
